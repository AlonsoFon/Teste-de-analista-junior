<!DOCTYPE html>
<html lang="en">


<!-- Chamando o header.blade.php que contem as chamadas do css e o header -->
@include('header_index')

@if (session('alert'))
    <div class="alert alert-success">
        {{ session('alert') }}
    </div>
@endif

@if (session('error1'))
    <div class="alert alert-danger">
        {{ session('error1') }}
    </div>
@endif
<?php 
use App\Filmes;
use App\Usuario;
use App\Endereco;


$Filmes = Filmes::all();

$titulo = array();
$ano = array();
$diretor = array();
$nota_do_filme = array();
$sinopse_do_filme = array();

foreach ($Filmes as $row) {
	if($row->email == $email){
		$titulo[] = $row->titulo;
		$ano[] = $row->ano;
		$diretor[] = $row->diretor;
		$nota_do_filme[] = $row->nota_do_filme;
		$sinopse_do_filme[] = $row->sinopse_do_filme;

	}
}
$tamanho = count($titulo);

$nome_usuario = array();
$email_usuario = array();
$endereco_usuario = array();


$Usuario = Usuario::all();
$Endereco = Endereco::all();
$array_de_filmes = array();

foreach ($Usuario as $row) {
	if($row->email != $email){
		$nome_usuario[] = $row->nome;
		$email_usuario[] = $row->email;
		$endereco_completo_principal = "";
		$endereco_completo_secundario = "";
		$endereco_completo_principal = $row->logradouro." ".$row->numero.", ".$row->bairro.", ".$row->complemento.", ".$row->cidade." ".$row->estado;
		$array_de_enderecos = array();
		$array_de_filme = array();
		foreach ($Endereco as $row_aux) {
			if($row->email == $row_aux->email){
				$endereco_completo_secundario = $row_aux->logradouro." ".$row_aux->numero.", ".$row_aux->bairro.", ".$row_aux->complemento.", ".$row_aux->cidade." ".$row_aux->estado;
				$array_de_enderecos[] = $endereco_completo_secundario;
			}
		}
		foreach ($Filmes as $film) {
			if($row->email == $film->email){
				$array_de_filme[] = '<div class="row">Titulo: '.$film->titulo.'</div><div class="row">Ano: '.$film->ano.'</div><div class="row">Diretor: '.$film->diretor.'</div><div class="row">Nota do filme: '.$film->nota_do_filme.'</div><div class="row">Sinopse do filme: '.$film->sinopse_do_filme."</div>";
			}
		}
		$array_de_filmes[] = $array_de_filme;
		$endereco_usuario[] = array($endereco_completo_principal,$array_de_enderecos);

	}
}
$filmes_json = json_encode($array_de_filmes);


$endereco_usuario_json = json_encode($endereco_usuario);
$tamanho_usuario = count($nome_usuario);

?>




<div class="row">
	<div class="col-sm-12 col-xs-12 " >
        <div class="card" style="margin-top: 80px;">
            <div class="card-body" >
                <div class="d-flex no-block">
					<div class="col-sm-6">
                        <h4 class="card-title">Usuarios do sistema:</h4>
				    	<div class="table-responsive" style="margin-bottom:20px">
                    		<input type="text" class="form-control"  id="myInput_usuario" onkeyup="myFunction_usuario()" placeholder="Pesquisar">
                    	</div>              
				    </div>
				    
                </div>
                <div class="table-responsive">
                    <table class="table stylish-table" id="myTable_usuario">
                        <thead>
                            <tr>
                                <th>Nome</th>
                                <th>Email</th>
                               	<th>Endere&ccedil;o principal</th>
                               	<th>Outros endere&ccedil;os</th>
                               	<th>Listar filmes</th>
                            </tr>
                       	</thead>
                        <tbody>
                        <?php
                           	for ($i = 0; $i < $tamanho_usuario ; $i++){
                                echo "<tr>";
                                    echo "<td>";
                                        			echo "<h6>".$nome_usuario[$i]."</h6>";
                                    echo "</td>";
                                    echo "<td>";
                                        			echo "<h6>".$email_usuario[$i]."</h6>";
                                    echo "</td>";
                                    echo "<td>";
                                        			echo "<h6>".$endereco_usuario[$i][0]."</h6>";
                                    echo "</td>";
                                    echo "<td>";
                                   	echo "<button type=\"button\" onclick=\"visualizar_mais_enderecos('".$i."');\" class=\"btn btn-success waves-effect waves-light\"> Outros endere&ccedil;os </button>";
                                   	echo "</td>";
                                   	echo "<td>";
                                   	echo "<button type=\"button\" onclick=\"visualizar_filmes('".$i."');\" class=\"btn btn-success waves-effect waves-light\"> Listar filmes </button>";
                                   	echo "</td>";
                                    
                                echo "</tr>";
                        
                            }
                                           
                        ?>
                                            
                        </tbody>
                    </table>
                </div>
            </div>
     	</div>
    </div>                    
</div>

<div class="row">
	<div class="col-sm-12 col-xs-12 " >
        <div class="card" style="margin-top: 80px;">
            <div class="card-body" >
                <div class="d-flex no-block">
					<div class="col-sm-6">
                        <h4 class="card-title">Seus Filmes:</h4>
				    	<div class="table-responsive" style="margin-bottom:20px">
                    		<input type="text" class="form-control"  id="myInput" onkeyup="myFunction()" placeholder="Pesquisar">
                    	</div>              
				    </div>
				    
                </div>
                <div class="table-responsive">
                    <table class="table stylish-table" id="myTable">
                        <thead>
                            <tr>
                                <th>Titulo do filme</th>
                                <th>Ano</th>
                               	<th>Diretor</th>
                               	<th>Nota</th>
                               	<th>Sinopse</th>
                            </tr>
                       	</thead>

                        <tbody>
                        <?php
                           	for ($i = 0; $i < $tamanho ; $i++){
                                echo "<tr>";
                                    echo "<td>";
                                        			echo "<h6>".$titulo[$i]."</h6>";
                                    echo "</td>";
                                    echo "<td>";
                                        			echo "<h6>".$ano[$i]."</h6>";
                                    echo "</td>";
                                    echo "<td>";
                                        			echo "<h6>".$diretor[$i]."</h6>";
                                    echo "</td>";
                                    echo "<td>";
                                        			echo "<h6>".$nota_do_filme[$i]."</h6>";
                                    echo "</td>";
                                    echo "<td>";
                                        			echo "<h6>".$sinopse_do_filme[$i]."</h6>";
                                    echo "</td>";
                                    
                                echo "</tr>";
                        
                            }
                                           
                        ?>
                                            
                        </tbody>
                    </table>
                </div>
            </div>
     	</div>
    </div>                    
</div>

<div id="modal_enderecos" class="modal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
	<div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title" id="myModalLabel">Enrede&ccedil;os</h4>
				<button type="button" onclick="close_modal();" class="close" data-dismiss="modal" aria-hidden="true">X</button> 
			</div>
            <div class="modal-body">
            	<div id="append_here"></div>                    
            </div>
                        
        </div>
    </div>
</div>

<div id="modal_filmes" class="modal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
	<div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title" id="myModalLabel">Lista de filmes</h4>
				<button type="button" onclick="close_modal_filmes();" class="close" data-dismiss="modal" aria-hidden="true">X</button> 
			</div>
            <div class="modal-body">
            	<div id="append_here_filmes"></div>                    
            </div>
                        
        </div>
    </div>
</div>



<!-- Fechando as divs e o body do header -->


</div>
</div>
</div>



  
</body>
<!-- Chamando o footer.blade.php que contem as chamadas do js e o footer -->
@include('footer')

<script>
function myFunction() {
  // Declare variables 
  var input, filter, table, tr, td, i;
  input = document.getElementById("myInput");
  filter = input.value.toUpperCase();
  table = document.getElementById("myTable");
  tr = table.getElementsByTagName("tr");

  // Loop through all table rows, and hide those who don't match the search query
  for (i = 0; i < tr.length; i++) {
    td = tr[i].getElementsByTagName("td")[0];
    if (td) {
      if (td.innerHTML.toUpperCase().indexOf(filter) > -1) {
        tr[i].style.display = "";
      } else {
        tr[i].style.display = "none";
      }
    } 
  }
}
function myFunction_usuario() {
  // Declare variables 
  var input, filter, table, tr, td, i;
  input = document.getElementById("myInput_usuario");
  filter = input.value.toUpperCase();
  table = document.getElementById("myTable_usuario");
  tr = table.getElementsByTagName("tr");

  // Loop through all table rows, and hide those who don't match the search query
  for (i = 0; i < tr.length; i++) {
    td = tr[i].getElementsByTagName("td")[0];
    if (td) {
      if (td.innerHTML.toUpperCase().indexOf(filter) > -1) {
        tr[i].style.display = "";
      } else {
        tr[i].style.display = "none";
      }
    } 
  }
}

function visualizar_mais_enderecos(posicao){
	var objTo = document.getElementById('append_here')
    var divtest = document.createElement("div");
    var array_de_enderecos_de_todos = [];
    var array_de_enderecos = [];
    array_de_enderecos_de_todos = <?php echo $endereco_usuario_json; ?>;
    array_de_enderecos = array_de_enderecos_de_todos[posicao][1];
    var tam_end = array_de_enderecos.length;
    var div_end = "";
    for(var i = 0; i < tam_end; i++){
    	var num = i + 1;
    	div_end = div_end+'<div class="row"> '+num+' - '+array_de_enderecos[i] +'</div><br>';
    }

	divtest.innerHTML = '<div class="card">'
        +'<div class="card-body">'
        +'<h4 class="card-title">Outros endere&ccedil;os:</h4>'
        +div_end
        +'</div>'
        +'</div>';
	objTo.appendChild(divtest);
    document.getElementById('modal_enderecos').style.position="absolute";
	$('#modal_enderecos').show();
}
function close_modal(){
	var education_fields = document.getElementById('append_here');
    while(education_fields.firstChild){
        education_fields.removeChild(education_fields.firstChild);
    }
	$('#modal_enderecos').hide();
}
function visualizar_filmes(posicao){
	var objTo = document.getElementById('append_here_filmes');
   
    var todos_os_filmes = <?php echo $filmes_json; ?>;
    var filme_selecionado = todos_os_filmes[posicao];
    var tam_filmes = filme_selecionado.length;
    for (var i =0; i < tam_filmes; i++){
    	var num = i + 1;
    	 var divtest = document.createElement("div");
    	divtest.innerHTML = '<div class="card">'
        +'<div class="card-body">'
        +'<h4 class="card-title">Filme '+num+': </h4>'
        +filme_selecionado[i]
        +'</div>'
        +'</div>';
		objTo.appendChild(divtest);
    }
    $('#modal_filmes').show();
    document.getElementById('modal_filmes').style.position="absolute";
}

function close_modal_filmes(){
	var education_fields = document.getElementById('append_here_filmes');
    while(education_fields.firstChild){
        education_fields.removeChild(education_fields.firstChild);
    }
	$('#modal_filmes').hide();
}
</script>