<!DOCTYPE html>
<html lang="en">

<!-- Chamando o header.blade.php que contem as chamadas do css e o header -->

@include('header_login')


<div class="row">
    <div class="col-10">
        <div class="card card-body" style=" left:50px; margin-top: 80px;">
            <h3 class="box-title m-b-0">Cadastro de usuarios</h3>
            <p class="text-muted m-b-30 font-13"> Insira suas informa&ccedil;&otilde;es abaixo </p>
            
            <div class="row">
                <div class="col-sm-12 col-xs-12">
                    
                    <form class="floating-labels m-t-40">
                        <div class="form-group">
                            <label for="exampleInputEmail1">Nome:<span style="color:red">*</span>
                            </label>
                            <input type="text" class="form-control" id="nome" name="nome" value="{{old('nome')}}" >
                            <input type="hidden" id="primeiro_endereco" name="primeiro_endereco" value="-1" > 
                            @if (count($errors) > 0)
                                @if ($errors->has('nome')) 
                                    <br>
                                    <div class = "alert alert-danger">
                                        <ul>
                                        <li>{{ $errors->first('nome') }}</li>
                                        </ul>
                                    </div>
                                @endif
                             @endif
                            <input type="hidden" name="_token" value="{{csrf_token()}}">
                        </div>
                        <div class="form-group">
                            <label for="exampleInputEmail1">Sobrenome:<span style="color:red">*</span></label>
                            <input type="sobrenome" class="form-control" id="sobrenome" name="sobrenome" value="{{old('sobrenome')}}" >
                            @if (count($errors) > 0)
                                @if ($errors->has('sobrenome')) 
                                    <br>
                                    <div class = "alert alert-danger">
                                        <ul>
                                        <li>{{ $errors->first('sobrenome') }}</li>
                                        </ul>
                                    </div>
                                @endif
                             @endif
                        </div>
                        <div class="form-group">
                            <label for="exampleInputEmail1">Email:<span style="color:red">*</span></label>
                            <input type="email" class="form-control" id="email" name="email" value="{{old('email')}}" >
                            @if (count($errors) > 0)
                                @if ($errors->has('email')) 
                                    <br>
                                    <div class = "alert alert-danger">
                                        <ul>
                                        <li>{{ $errors->first('email') }}</li>
                                        </ul>
                                    </div>
                                @endif
                             @endif
                        </div>
                        <div class="form-group">
                            <label for="exampleInputPassword1">Senha:<span style="color:red">*</span></label>
                            <input type="password" class="form-control" id="senha" name="senha" value="">

                            <div class="form-group" style="margin-top: 20px">
                            <label for="exampleInputPassword1">Confirmar senha:<span style="color:red">*</span></label>
                            <input type="password" class="form-control" id="senha_confirmation" name="senha_confirmation" >
                            </div>
                            @if (count($errors) > 0)
                                @if ($errors->has('senha')) 
                                    <div class = "alert alert-danger">
                                        <ul>
                                        <li>{{ $errors->first('senha') }}</li>
                                        </ul>
                                    </div>
                                @endif
                             @endif
                        </div>
                        <div class="form-group">
                            <label for="exampleInputEmail1">Telefone:<span style="color:red">*</span></label>
                            <input type="text" class="form-control" id="telefone" name="telefone" value="{{old('telefone')}}" data-mask="(99) 99999-9999">
                             @if (count($errors) > 0)
                                @if ($errors->has('telefone')) 
                                    <br>
                                    <div class = "alert alert-danger">
                                        <ul>
                                        <li>{{ $errors->first('telefone') }}</li>
                                        </ul>
                                    </div>
                                @endif
                             @endif
                        </div>

                       
                        <div class="form-group">
                            <label for="exampleInputEmail1">Cpf:<span style="color:red">*</span></label>
                            <input type="text" class="form-control" id="cpf" name="cpf" <?php if (count($errors) > 0){ ?> value="" <?php } else{ ?> value="{{old('cpf')}}" <?php } ?> data-mask="999.999.999-99" >
                             @if (count($errors) > 0)
                                @if ($errors->has('cpf')) 
                                    <br>
                                    <div class = "alert alert-danger">
                                        <ul>
                                        <li>{{ $errors->first('cpf') }}</li>
                                        </ul>
                                    </div>
                                @endif
                             @endif
                        </div>
                        <div class="form-group">
                            <label for="exampleInputEmail1">Rg:<span style="color:red">*</span></label>
                            <input type="text" class="form-control" id="rg" name="rg" value="{{old('rg')}}" data-mask="9999999-9" >
                             @if (count($errors) > 0)
                                @if ($errors->has('rg')) 
                                    <br>
                                    <div class = "alert alert-danger">
                                        <ul>
                                        <li>{{ $errors->first('rg') }}</li>
                                        </ul>
                                    </div>
                                @endif
                             @endif
                        </div>
                        <div class="form-group">
                            <label for="exampleInputEmail1">Titula&ccedil;&atilde;o:<span style="color:red">*</span></label>
                            <input type="text" class="form-control" id="titulacao" name="titulacao" value="{{old('titulacao')}}" >
                             @if (count($errors) > 0)
                                @if ($errors->has('titulacao')) 
                                    <br>
                                    <div class = "alert alert-danger">
                                        <ul>
                                        <li>{{ $errors->first('titulacao') }}</li>
                                        </ul>
                                    </div>
                                @endif
                             @endif
                        </div>
                        
                       <!-- div endereco -->
                       <div class="card">
                            <div class="card-body">
                                <h4 class="card-title">Endere&ccedil;o:</h4>
                                <div class="row">
                                    <div class="col-sm-3 nopadding">
                                        <div class="form-group">
                                            <input type="text" class="form-control" id="logradouro" name="logradouro[]" value="" placeholder="Logradouro">
                                        </div>
                                    </div>
                                    <div class="col-sm-3 nopadding">
                                        <div class="form-group">
                                            <input type="text" class="form-control" id="bairro" name="bairro[]" value="" placeholder="Bairro">
                                        </div>
                                    </div>
                                    <div class="col-sm-3 nopadding">
                                        <div class="form-group">
                                            <input type="text" class="form-control" id="numero" name="numero[]" value="" placeholder="Numero">
                                        </div>
                                    </div>
                                    <div class="col-sm-3 nopadding">
                                        <div class="form-group">
                                            <input type="text" class="form-control" id="complemento" name="complemento[]" value="" placeholder="Complemento">
                                        </div>
                                    </div>
                                </div>
                               <?php
                                   $estado = "";
                                   $estado = old('estado');
                               ?>
                                <div class="row">
                                    <div class="col-sm-4 nopadding">
                                        <div class="form-group">
                                            <input type="text" class="form-control" id="cidade" name="cidade[]" value="" placeholder="cidade">
                                        </div>
                                    </div>
                                    <div class="col-sm-3 nopadding" style="margin-top:10px">
                                        <div class="form-group">
                                            <select  class="custom-select" name="estado[]">
                                            <option  selected  value="Acre">Acre</option>
                                            <option  value="Alagoas">Alagoas</option>
                                            <option  value="Amapa">Amap&aacute;</option>
                                            <option  value="Amazonas">Amazonas</option>
                                            <option  value="Bahia">Bahia</option>
                                            <option  value="Ceara">Cear&aacute;</option>
                                            <option  value="Distrito Federal">Distrito Federal</option>
                                            <option  value="Espirito Santo">Esp&iacute;rito Santo</option>
                                            <option  value="Goias">Goi&aacute;s</option>
                                            <option  value="Maranhao">Maranh&atilde;o</option>
                                            <option  value="Mato Grosso">Mato Grosso</option>
                                            <option  value="Mato Grosso do Sul">Mato Grosso do Sul</option>
                                            <option  value="Minas Gerais">Minas Gerais</option>
                                            <option  value="Para">Par&aacute;</option>
                                            <option  value="Paraiba">Para&iacute;ba</option>
                                            <option  value="Parana">Paran&aacute;</option>
                                            <option  value="Pernambuco">Pernambuco</option>
                                            <option  value="Piaui">Piau&iacute;</option>
                                            <option  value="Rio de Janeiro">Rio de Janeiro</option>
                                            <option  value="Rio Grande do Norte">Rio Grande do Norte</option>
                                            <option  value="Rio Grande do Sul">Rio Grande do Sul</option>
                                            <option  value="Rondonia">Rond&ocirc;nia</option>
                                            <option  value="Roraima">Roraima</option>
                                            <option  value="Santa Catarina">Santa Catarina</option>
                                            <option  value="Sao Paulo">S&atilde;o Paulo</option>
                                            <option  value="Sergipe">Sergipe</option>
                                            <option  value="Tocantins">Tocantins</option>

                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-sm-4 nopadding" style="margin-top:10px">
                                        <div class="form-group" >
                                            <input name="group1[]" onclick="muda_valor(0)" style="left: 0px" type="radio" id="radio_0" value="0" > 
                                            <label for="radio_0">Seu endere&ccedil;o principal?</label>
                                        </div>
                                    </div>
                                    <div class="col-sm-1 nopadding" style="margin-top:10px" >
                                        <div class="form-group">        
                                            <button class="btn btn-success" type="button" onclick="endereco_adicional();"><i class="fa fa-plus"></i></button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- div do endereco -->

                        <!-- div de enderecos adicionais -->
                        <div id="endereco_adicional"></div>
                        <!-- div de enderecos adicionais -->
                        <!-- div dos filmes -->
                        <div class="card">
                            <div class="card-body">
                                <h4 class="card-title">Filmes:</h4>
                                <div class="row">
                                    <div class="col-sm-2 nopadding">
                                        <div class="form-group">
                                            <input type="text" class="form-control" id="titulo" name="titulo[]" value="" placeholder="Titulo do filme">
                                        </div>
                                    </div>
                                    <div class="col-sm-2 nopadding">
                                        <div class="form-group">
                                            <input type="text" class="form-control" id="ano" name="ano[]" value="" placeholder="Ano de lancamento">
                                        </div>
                                    </div>
                                    <div class="col-sm-2 nopadding">
                                        <div class="form-group">
                                            <input type="text" class="form-control" id="diretor" name="diretor[]" value="" placeholder="Diretor">
                                        </div>
                                    </div>
                                    <div class="col-sm-2 nopadding">
                                        <div class="form-group">
                                            <input type="text" class="form-control" id="nota_do_filme" name="nota_do_filme[]" value="" placeholder="Nota do filme">
                                        </div>
                                    </div>
                                    <div class="col-sm-2 nopadding">
                                        <div class="form-group">
                                            <input type="text" class="form-control" id="sinopse_do_filme" name="sinopse_do_filme[]" value="" placeholder="Sinopse do filme">
                                        </div>
                                    </div>
                                    <div class="col-sm-1 nopadding" style="margin-top:10px" >
                                        <div class="form-group">        
                                            <button class="btn btn-success" type="button" onclick="filme_adicional();"><i class="fa fa-plus"></i></button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- div dos filmes -->
                         <!-- div de enderecos adicionais -->
                        <div id="filme_adicional"></div>
                        <!-- div de enderecos adicionais -->
                        
            <div class="form-group">
                <input type="checkbox" id="aplica" onclick="aceitou();" name="aplica" value="1" class="filled-in chk-col-red" />
                                <label for="aplica" style="margin-right:50px">Aceitar termos de uso</label>
                <a href="#"  > <br>Ler termos de uso do site</a>
            </div>
            <br>
            <div class="form-group">
                            <button type="submit" style="display:none" id="cadastrar" formmethod="post" class="btn btn-success waves-effect waves-light m-r-10">Cadastrar</button>
                            <button type="button" onclick="voltar();" class="btn btn-inverse waves-effect waves-light">Voltar</button>
                            <a href="/login" style="display:none" id="ex">Triggerable link</a>
                        </div>
                    </form>
                </div>
            </div>

            



        </div>
    </div>
</div>


<script>
    function voltar(){
        $('#ex').click();
        location.href=$('#ex').attr('href');
    }
</script>

<script>
    function aceitou(){
        if (!document.getElementById('aplica').checked) document.getElementById('cadastrar').style.display = 'none';
        else document.getElementById('cadastrar').style.display = 'inline';
    }
    function muda_valor(id){
        var valor = 0;
        if (id != 0) valor = id -1;
        else valor = id;
        document.getElementById('primeiro_endereco').value = valor;
    }
</script>
<script type="text/javascript">
    var room_filme = 1;
    var conta_filme  = 0;
    var conta_2_filme = 0;

    var titulo_antigo = [];
    var ano_antigo  = [];
    var diretor_antigo  = [];
    var nota_do_filme_antigo = [];
    var sinopse_do_filme_antigo = [];
    var excluir_filme = 0;
    function filme_adicional(){
        var posicao = 0;
        var elemento1 = document.getElementsByName('titulo[]');
        var elemento2 = document.getElementsByName('ano[]');
        var elemento3 = document.getElementsByName('diretor[]');
        var elemento4 = document.getElementsByName('nota_do_filme[]');
        var elemento5 = document.getElementsByName('sinopse_do_filme[]');
        if(elemento1[posicao].value !== ""){
        var valor1 = elemento1[posicao].value;
        }else{
            var valor1 = "";
        }

        if(elemento2[posicao].value !== ""){
            var valor2 = elemento2[posicao].value;
        }else{
            var valor2 = "";
        }

        if(elemento3[posicao].value !== ""){
            var valor3 = elemento3[posicao].value;
        }else{
            var valor3 = "";
        }

        if(elemento4[posicao].value !== ""){
            var valor4 = elemento4[posicao].value;
        }else{
            var valor4 = "";
        }
        if(elemento5[posicao].value !== ""){
            var valor5 = elemento5[posicao].value;
        }else{
            var valor5 = "";
        }
        elemento1[posicao].value="";
        elemento2[posicao].value="";
        elemento3[posicao].value="";
        elemento4[posicao].value="";
        elemento5[posicao].value="";
        elemento1[posicao].focus();
        if( (valor1 !== "") && (valor2 !== "") && (valor3 !== "")  && (valor5 !== "") ){
            titulo_antigo[conta_2_filme] = valor1;
            ano_antigo[conta_2_filme]  = valor2;
            diretor_antigo[conta_2_filme]  = valor3;
            nota_do_filme_antigo[conta_2_filme] = valor4;
            sinopse_do_filme_antigo[conta_2_filme] = valor5;


            room_filme++;
            var objTo = document.getElementById('filme_adicional');
            var divtest = document.createElement("div");
            divtest.setAttribute("class", "form-group removeclass_filme" + room_filme);

                                    
                                        
                                    
                                    
                                

            var rdiv = 'removeclass_filme' + room_filme;

            var valor1_aux = "'"+valor1+"'";                                        
            divtest.innerHTML = '<div class="card">'
            +'<div class="card-body">'
            +'<h4 class="card-title">Filmes:</h4>'
            +'<div class="row">'
            +'<div class="col-sm-2 nopadding">'
            +'<div class="form-group">'
            +'<input type="text" class="form-control" id="titulo" name="titulo[]" value="'+valor1+'" placeholder="Titulo do filme">'
            +'</div>'
            +'</div>'
            +'<div class="col-sm-2 nopadding">'
            +'<div class="form-group">'
            +'<input type="text" class="form-control" id="ano" name="ano[]" value="'+valor2+'" placeholder="Ano de lancamento">'
            +'</div>'
            +'</div>'
            +'<div class="col-sm-2 nopadding">'
            +'<div class="form-group">'
            +'<input type="text" class="form-control" id="diretor" name="diretor[]" value="'+valor3+'" placeholder="Diretor">'
            +'</div>'
            +'</div>'
            +'<div class="col-sm-2 nopadding">'
            +'<div class="form-group">'
            +'<input type="text" class="form-control" id="nota_do_filme" name="nota_do_filme[]" value="'+valor4+'" placeholder="Nota do filme">'
            +'</div>'
            +'</div>'
            +'<div class="col-sm-2 nopadding">'
            +'<div class="form-group">'
            +'<input type="text" class="form-control" id="sinopse_do_filme" name="sinopse_do_filme[]" value="'+valor5+'" placeholder="Sinopse do filme">'
            +'</div>'
            +'</div>'
            +'<div class="col-sm-1 nopadding" style="margin-top:10px" >'
            +'<div class="form-group">'        
            +'<button id="botao_filmes'+room_filme+'" class="btn btn-danger"  type="button" onclick="remove_education_fields_filme(' + room_filme + ','+valor1_aux+');"> <i class="fa fa-minus"></i>   '
            +'</button>'
            +'</div>'
            +'</div>'
            +'</div>'
            +'</div>'
            objTo.appendChild(divtest);

            var titulo  = document.getElementsByName('titulo[]');
            var ano  = document.getElementsByName('ano[]');
            var diretor  = document.getElementsByName('diretor[]');
            var nota_do_filme = document.getElementsByName('nota_do_filme[]');
            var sinopse_do_filme = document.getElementsByName('sinopse_do_filme[]');

            var troca = "";

            var tam_titulo = titulo.length;

            
            var titulo_reverse = [];
            var ano_reverse  = [];
            var diretor_reverse  = [];
            var nota_do_filme_reverse = [];
            var sinopse_do_filme_reverse = [];


            titulo_reverse = titulo_antigo.slice();
            ano_reverse  = ano_antigo.slice(); 
            diretor_reverse  = diretor_antigo.slice(); 
            nota_do_filme_reverse = nota_do_filme_antigo.slice(); 
            sinopse_do_filme_reverse = sinopse_do_filme_antigo.slice(); 

            
            titulo_reverse.reverse();
            ano_reverse.reverse();
            diretor_reverse.reverse();
            nota_do_filme_reverse.reverse();
            sinopse_do_filme_reverse.reverse();



            j = 0;
            for(var i = 1; i < tam_titulo; i++){
                titulo[i].value  = titulo_reverse[j];
                ano[i].value  = ano_reverse[j];
                diretor[i].value = diretor_reverse[j];
                nota_do_filme[i].value  = nota_do_filme_reverse[j];
                sinopse_do_filme[i].value  = sinopse_do_filme_reverse[j];



                    var i_i = i + 1; 
                var pos_id = 'botao_filmes'+i_i;

                document.getElementById(pos_id).setAttribute('onclick','remove_education_fields_filme('+i_i+',"'+titulo_reverse[j]+'")');


                j++;
            }
            conta_2_filme++;
        }else{
            alert('preencha todos os campos');
        }
    }
function remove_education_fields_filme(rid,valor1_funcao) {

    var posicao_remove = 0;
    posicao_remove = titulo_antigo.indexOf(valor1_funcao);
    titulo_antigo.splice(posicao_remove,1);
    ano_antigo.splice(posicao_remove,1);    
    diretor_antigo.splice(posicao_remove,1);    
    nota_do_filme_antigo.splice(posicao_remove,1);
    sinopse_do_filme_antigo.splice(posicao_remove,1);    


    var education_fields = document.getElementById('filme_adicional');
    while(education_fields.firstChild){
        education_fields.removeChild(education_fields.firstChild);
    }

    conta_2_filme--;
    room_filme = 1;

    titulo_reverse = titulo_antigo.slice();
    ano_reverse  = ano_antigo.slice(); 
    diretor_reverse  = diretor_antigo.slice(); 
    nota_do_filme_reverse = nota_do_filme_antigo.slice(); 
    sinopse_do_filme_reverse = sinopse_do_filme_antigo.slice(); 


    titulo_reverse.reverse();
    ano_reverse.reverse();
    diretor_reverse.reverse();
    nota_do_filme_reverse.reverse();
    sinopse_do_filme_reverse.reverse();


    var tamanho_reverse = titulo_reverse.length;
    for(var i = 0; i < tamanho_reverse; i++){

        room_filme++;
        var objTo = document.getElementById('filme_adicional')
        var divtest = document.createElement("div");
        divtest.setAttribute("class", "form-group removeclass_filme" + room_filme);
        var rdiv = 'removeclass_filme' + room_filme;
        
        var titulo_reverse_aux = "'"+titulo_reverse[i]+"'";
        
        divtest.innerHTML = '<div class="card">'
            +'<div class="card-body">'
            +'<h4 class="card-title">Filmes:</h4>'
            +'<div class="row">'
            +'<div class="col-sm-2 nopadding">'
            +'<div class="form-group">'
            +'<input type="text" class="form-control" id="titulo" name="titulo[]" value="'+titulo_reverse[i]+'" placeholder="Titulo do filme">'
            +'</div>'
            +'</div>'
            +'<div class="col-sm-2 nopadding">'
            +'<div class="form-group">'
            +'<input type="text" class="form-control" id="ano" name="ano[]" value="'+ano_reverse[i]+'" placeholder="Ano de lancamento">'
            +'</div>'
            +'</div>'
            +'<div class="col-sm-2 nopadding">'
            +'<div class="form-group">'
            +'<input type="text" class="form-control" id="diretor" name="diretor[]" value="'+diretor_reverse[i]+'" placeholder="Diretor">'
            +'</div>'
            +'</div>'
            +'<div class="col-sm-2 nopadding">'
            +'<div class="form-group">'
            +'<input type="text" class="form-control" id="nota_do_filme" name="nota_do_filme[]" value="'+nota_do_filme_reverse[i]+'" placeholder="Nota do filme">'
            +'</div>'
            +'</div>'
            +'<div class="col-sm-2 nopadding">'
            +'<div class="form-group">'
            +'<input type="text" class="form-control" id="sinopse_do_filme" name="sinopse_do_filme[]" value="'+sinopse_do_filme_reverse[i]+'" placeholder="Sinopse do filme">'
            +'</div>'
            +'</div>'
            +'<div class="col-sm-1 nopadding" style="margin-top:10px" >'
            +'<div class="form-group">'        
            +'<button id="botao_filmes'+room_filme+'" class="btn btn-danger"  type="button" onclick="remove_education_fields_filme(' + room_filme + ','+titulo_reverse_aux+');"> <i class="fa fa-minus"></i>   '
            +'</button>'
            +'</div>'
            +'</div>'
            +'</div>'
            +'</div>'
        objTo.appendChild(divtest);

        var i_i = i + 2; 
        var pos_id = 'botao_filmes'+i_i;

        document.getElementById(pos_id).setAttribute('onclick','remove_education_fields_filme('+i_i+',"'+titulo_reverse[i]+'")');
    } 
    conta_filme++;
}
</script>

<script type="text/javascript">
    var room = 1;
    var conta  = 0;
    var conta_2 = 0;

    var logradouro_antigo = [];
    var bairro_antigo  = [];
    var numero_antigo  = [];
    var complemento_antigo = [];
    var cidade_antigo = [];
    var estado_antigo = [];
    var excluir = 0;

function endereco_adicional() {
    var posicao = 0;
     
     
    var elemento1 = document.getElementsByName('logradouro[]');
    var elemento2 = document.getElementsByName('bairro[]');
    var elemento3 = document.getElementsByName('numero[]');
    var elemento4 = document.getElementsByName('complemento[]');
    var elemento5 = document.getElementsByName('cidade[]');
    var elemento6 = document.getElementsByName('estado[]');
    

    if(elemento1[posicao].value !== ""){
        var valor1 = elemento1[posicao].value;
    }else{
        var valor1 = "";
    }

    if(elemento2[posicao].value !== ""){
        var valor2 = elemento2[posicao].value;
    }else{
        var valor2 = "";
    }

    if(elemento3[posicao].value !== ""){
        var valor3 = elemento3[posicao].value;
    }else{
        var valor3 = "";
    }

    if(elemento4[posicao].value !== ""){
        var valor4 = elemento4[posicao].value;
    }else{
        var valor4 = "";
    }
    if(elemento5[posicao].value !== ""){
        var valor5 = elemento5[posicao].value;
    }else{
        var valor5 = "";
    }
    if(elemento6[posicao].value !== ""){
        var valor6 = elemento6[posicao].value;
    }else{
        var valor6 = "";
    }
    var sel1 = sel2 = sel3 = sel4 = sel5 = sel6 = sel7 = sel8 = sel9 = sel10 = "";
    var sel11 = sel12 = sel13 = sel14 = sel15 = sel16 = sel17 = sel18 = sel19 = sel20 = "";
    var sel21 = sel22 = sel23 = sel24 = sel25 = sel26 = sel27 = "";

    if(valor6 == "Acre") sel1 = "selected"; if(valor6 == "Alagoas") sel2 = "selected"; 
    if(valor6 == "Amapa") sel3 = "selected"; if(valor6 == "Amazonas") sel4 = "selected";
    if(valor6 == "Bahia") sel5 = "selected"; if(valor6 == "Ceara") sel6 = "selected";
    if(valor6 == "Distrito Federal") sel7 = "selected"; if(valor6 == "Espirito Santo") sel8 = "selected";
    if(valor6 == "Goias") sel9 = "selected"; if(valor6 == "Maranhao") sel10 = "selected";
    if(valor6 == "Mato Grosso") sel11 = "selected"; if(valor6 == "Mato Grosso do Sul") sel12 = "selected";
    if(valor6 == "Minas Gerais") sel13 = "selected"; if(valor6 == "Para") sel14 = "selected";
    if(valor6 == "Paraiba") sel15 = "selected"; if(valor6 == "Parana") sel16 = "selected";
    if(valor6 == "Pernambuco") sel17 = "selected"; if(valor6 == "Piaui") sel18 = "selected";
    if(valor6 == "Rio de Janeiro") sel19 = "selected"; if(valor6 == "Rio Grande do Norte") sel20 = "selected";
    if(valor6 == "Rio Grande do Sul") sel21 = "selected"; if(valor6 == "Rondonia") sel22 = "selected";
    if(valor6 == "Roraima") sel23 = "selected"; if(valor6 == "Santa Catarina") sel24 = "selected";
    if(valor6 == "Sao Paulo") sel25 = "selected"; if(valor6 == "Sergipe") sel26 = "selected";
    if(valor6 == "Tocantins") sel27 = "selected"; 

    elemento1[posicao].value="";
    elemento2[posicao].value="";
    elemento3[posicao].value="";
    elemento4[posicao].value="";
    elemento5[posicao].value="";
    elemento1[posicao].focus();

    

    if( (valor1 !== "") && (valor2 !== "") && (valor3 !== "")  && (valor5 !== "") ){
        logradouro_antigo[conta_2] = valor1;
        bairro_antigo[conta_2]  = valor2;
        numero_antigo[conta_2]  = valor3;
        complemento_antigo[conta_2] = valor4;
        cidade_antigo[conta_2] = valor5;
        estado_antigo[conta_2] = valor6;


        room++;
        var objTo = document.getElementById('endereco_adicional');
        var divtest = document.createElement("div");
        divtest.setAttribute("class", "form-group removeclass" + room);

                                
                                    
                                
                                
                            

        var rdiv = 'removeclass' + room;
        var valor1_aux = "'"+valor1+"'";        

        divtest.innerHTML = '<div class="card">'
        +'<div class="card-body">'
        +'<h4 class="card-title">Endereco:</h4>'
        +'<div class="row">'
        +'<div class="col-sm-3 nopadding">'
        +'<div class="form-group">'
        +'<input type="text" class="form-control" name="logradouro[]" value="'+valor1+'" placeholder="Logradouro">'
        +'</div>'
        +'</div>'
        +'<div class="col-sm-3 nopadding">'
        +'<div class="form-group">'
        +'<input type="text" class="form-control" name="bairro[]" value="'+valor2+'" placeholder="Bairro">'
        +'</div>'
        +'</div>'
        +'<div class="col-sm-3 nopadding">'
        +'<div class="form-group">'
        +'<input type="text" class="form-control" name="numero[]" value="'+valor3+'" placeholder="Numero">'
        +'</div>'
        +'</div>'
        +'<div class="col-sm-3 nopadding">'
        +'<div class="form-group">'
        +'<input type="text" class="form-control" name="complemento[]" value="'+valor4+'" placeholder="Complemento">'
        +'</div>'
        +'</div>'
        +'</div>'
        +'<div class="row">'
        +'<div class="col-sm-4 nopadding">'
        +'<div class="form-group">'
        +'<input type="text" class="form-control" name="cidade[]" value="'+valor5+'" placeholder="cidade">'
        +'</div>'
        +'</div>'
        +'<div class="col-sm-3 nopadding" style="margin-top:10px">'
        +'<div class="form-group">'
        +'<select  class="custom-select" name="estado[]">'
        +'<option '+sel1+' value="Acre">Acre</option>'
        +'<option '+sel2+' value="Alagoas">Alagoas</option>'
        +'<option '+sel3+'  value="Amapa">Amap&aacute;</option>'
        +'<option '+sel4+'  value="Amazonas">Amazonas</option>'
        +'<option '+sel5+'  value="Bahia">Bahia</option>'
        +'<option '+sel6+'  value="Ceara">Cear&aacute;</option>'
        +'<option '+sel7+'  value="Distrito Federal">Distrito Federal</option>'
        +'<option '+sel8+'  value="Espirito Santo">Esp&iacute;rito Santo</option>'
        +'<option '+sel9+'  value="Goias">Goi&aacute;s</option>'
        +'<option '+sel10+'  value="Maranhao">Maranh&atilde;o</option>'
        +'<option '+sel11+'  value="Mato Grosso">Mato Grosso</option>'
        +'<option '+sel12+'  value="Mato Grosso do Sul">Mato Grosso do Sul</option>'
        +'<option '+sel13+'  value="Minas Gerais">Minas Gerais</option>'
        +'<option '+sel14+'  value="Para">Par&aacute;</option>'
        +'<option '+sel15+'  value="Paraiba">Para&iacute;ba</option>'
        +'<option '+sel16+'  value="Parana">Paran&aacute;</option>'
        +'<option '+sel17+'  value="Pernambuco">Pernambuco</option>'
        +'<option '+sel18+'  value="Piaui">Piau&iacute;</option>'
        +'<option '+sel19+'  value="Rio de Janeiro">Rio de Janeiro</option>'
        +'<option '+sel20+'  value="Rio Grande do Norte">Rio Grande do Norte</option>'
        +'<option '+sel21+'  value="Rio Grande do Sul">Rio Grande do Sul</option>'
        +'<option '+sel22+'  value="Rondonia">Rond&ocirc;nia</option>'
        +'<option '+sel23+'  value="Roraima">Roraima</option>'
        +'<option '+sel24+'  value="Santa Catarina">Santa Catarina</option>'
        +'<option '+sel25+'  value="Sao Paulo">S&atilde;o Paulo</option>'
        +'<option '+sel26+'  value="Sergipe">Sergipe</option>'
        +'<option '+sel27+'  value="Tocantins">Tocantins</option>'
        +'</select>'
        +'</div>'
        +'</div>'
        +'<div class="col-sm-4 nopadding" style="margin-top:10px">'
        +'<div class="form-group" >'
        +'<input name="group1[]" onclick="muda_valor('+room+')" style="left: 0px" type="radio" id="radio_'+room+'" value="0" >' 
        +'<label for="radio_'+room+'">Seu endere&ccedil;o principal?</label>'
        +'</div>'
        +'</div>'
        +'<div class="col-sm-1 nopadding" style="margin-top:10px" >'
        +'<div class="form-group">'        
        +'<button id="botao_enderecos'+room+'" class="btn btn-danger"  type="button" onclick="remove_education_fields(' + room + ','+valor1_aux+');"> <i class="fa fa-minus"></i>   '
        +'</button>'
        +'</div>'
        +'</div>'
        +'</div>'
        +'</div>'
        +'</div>'
        +'</div>'
        objTo.appendChild(divtest);

        var logradouro  = document.getElementsByName('logradouro[]');
        var bairro  = document.getElementsByName('bairro[]');
        var numero  = document.getElementsByName('numero[]');
        var complemento = document.getElementsByName('complemento[]');
        var cidade = document.getElementsByName('cidade[]');
        var estado = document.getElementsByName('estado[]');
        var troca = "";

        var tam_logradouro = logradouro.length;

        
        var logradouro_reverse = [];
        var bairro_reverse  = [];
        var numero_reverse  = [];
        var complemento_reverse = [];
        var cidade_reverse = [];
        var estado_reverse = [];


        logradouro_reverse = logradouro_antigo.slice();
        bairro_reverse  = bairro_antigo.slice(); 
        numero_reverse  = numero_antigo.slice(); 
        complemento_reverse = complemento_antigo.slice(); 
        cidade_reverse = cidade_antigo.slice(); 
        estado_reverse = estado_antigo.slice(); 

        
        logradouro_reverse.reverse();
        bairro_reverse.reverse();
        numero_reverse.reverse();
        complemento_reverse.reverse();
        cidade_reverse.reverse();
        estado_reverse.reverse();



        j = 0;
        for(var i = 1; i < tam_logradouro; i++){
            logradouro[i].value  = logradouro_reverse[j];
            bairro[i].value  = bairro_reverse[j];
            numero[i].value = numero_reverse[j];
            complemento[i].value  = complemento_reverse[j];
            cidade[i].value  = cidade_reverse[j];
            estado[i].value  = estado_reverse[j];



                var i_i = i + 1; 
                var pos_id = 'botao_enderecos'+i_i;

            document.getElementById(pos_id).setAttribute('onclick','remove_education_fields('+i_i+',"'+logradouro_reverse[j]+'")');


            j++;
        }
        conta_2++;
    }else{
        alert('preencha todos os campos');
    }
}

function remove_education_fields(rid,valor1_funcao) {

    var posicao_remove = 0;
    posicao_remove = logradouro_antigo.indexOf(valor1_funcao);
    logradouro_antigo.splice(posicao_remove,1);
    bairro_antigo.splice(posicao_remove,1);    
    numero_antigo.splice(posicao_remove,1);    
    complemento_antigo.splice(posicao_remove,1);
    cidade_antigo.splice(posicao_remove,1);    
    estado_antigo.splice(posicao_remove,1);    


    var education_fields = document.getElementById('endereco_adicional');
    while(education_fields.firstChild){
        education_fields.removeChild(education_fields.firstChild);
    }

    conta_2--;
    room = 1;

    logradouro_reverse = logradouro_antigo.slice();
    bairro_reverse  = bairro_antigo.slice(); 
    numero_reverse  = numero_antigo.slice(); 
    complemento_reverse = complemento_antigo.slice(); 
    cidade_reverse = cidade_antigo.slice(); 
    estado_reverse = estado_antigo.slice(); 


    logradouro_reverse.reverse();
    bairro_reverse.reverse();
    numero_reverse.reverse();
    complemento_reverse.reverse();
    cidade_reverse.reverse();
    estado_reverse.reverse();


    var tamanho_reverse = logradouro_reverse.length;
    for(var i = 0; i < tamanho_reverse; i++){

        room++;
        var objTo = document.getElementById('endereco_adicional')
        var divtest = document.createElement("div");
        divtest.setAttribute("class", "form-group removeclass" + room);
        var rdiv = 'removeclass' + room;
        
        var sel1 = sel2 = sel3 = sel4 = sel5 = sel6 = sel7 = sel8 = sel9 = sel10 = "";
        var sel11 = sel12 = sel13 = sel14 = sel15 = sel16 = sel17 = sel18 = sel19 = sel20 = "";
        var sel21 = sel22 = sel23 = sel24 = sel25 = sel26 = sel27 = "";

        if(estado_reverse[i] == "Acre") sel1 = "selected"; if(estado_reverse[i] == "Alagoas") sel2 = "selected"; 
        if(estado_reverse[i] == "Amapa") sel3 = "selected"; if(estado_reverse[i] == "Amazonas") sel4 = "selected";
        if(estado_reverse[i] == "Bahia") sel5 = "selected"; if(estado_reverse[i] == "Ceara") sel6 = "selected";
        if(estado_reverse[i] == "Distrito Federal") sel7 = "selected"; if(estado_reverse[i] == "Espirito Santo") sel8 = "selected";
        if(estado_reverse[i] == "Goias") sel9 = "selected"; if(estado_reverse[i] == "Maranhao") sel10 = "selected";
        if(estado_reverse[i] == "Mato Grosso") sel11 = "selected"; if(estado_reverse[i] == "Mato Grosso do Sul") sel12 = "selected";
        if(estado_reverse[i] == "Minas Gerais") sel13 = "selected"; if(estado_reverse[i] == "Para") sel14 = "selected";
        if(estado_reverse[i] == "Paraiba") sel15 = "selected"; if(estado_reverse[i] == "Parana") sel16 = "selected";
        if(estado_reverse[i] == "Pernambuco") sel17 = "selected"; if(estado_reverse[i] == "Piaui") sel18 = "selected";
        if(estado_reverse[i] == "Rio de Janeiro") sel19 = "selected"; if(estado_reverse[i] == "Rio Grande do Norte") sel20 = "selected";
        if(estado_reverse[i] == "Rio Grande do Sul") sel21 = "selected"; if(estado_reverse[i] == "Rondonia") sel22 = "selected";
        if(estado_reverse[i] == "Roraima") sel23 = "selected"; if(estado_reverse[i] == "Santa Catarina") sel24 = "selected";
        if(estado_reverse[i] == "Sao Paulo") sel25 = "selected"; if(estado_reverse[i] == "Sergipe") sel26 = "selected";
        if(estado_reverse[i] == "Tocantins") sel27 = "selected";

        var logradouro_reverse_aux = "'"+logradouro_reverse[i]+"'";

        divtest.innerHTML = '<div class="card">'
        +'<div class="card-body">'
        +'<h4 class="card-title">Endereco:</h4>'
        +'<div class="row">'
        +'<div class="col-sm-3 nopadding">'
        +'<div class="form-group">'
        +'<input type="text" class="form-control" name="logradouro[]" value="'+logradouro_reverse[i]+'" placeholder="Logradouro">'
        +'</div>'
        +'</div>'
        +'<div class="col-sm-3 nopadding">'
        +'<div class="form-group">'
        +'<input type="text" class="form-control" name="bairro[]" value="'+bairro_reverse[i]+'" placeholder="Bairro">'
        +'</div>'
        +'</div>'
        +'<div class="col-sm-3 nopadding">'
        +'<div class="form-group">'
        +'<input type="text" class="form-control" name="numero[]" value="'+numero_reverse[i]+'" placeholder="Numero">'
        +'</div>'
        +'</div>'
        +'<div class="col-sm-3 nopadding">'
        +'<div class="form-group">'
        +'<input type="text" class="form-control" name="complemento[]" value="'+complemento_reverse[i]+'" placeholder="Complemento">'
        +'</div>'
        +'</div>'
        +'</div>'
        +'<div class="row">'
        +'<div class="col-sm-4 nopadding">'
        +'<div class="form-group">'
        +'<input type="text" class="form-control" name="cidade[]" value="'+cidade_reverse[i]+'" placeholder="cidade">'
        +'</div>'
        +'</div>'
        +'<div class="col-sm-3 nopadding" style="margin-top:10px">'
        +'<div class="form-group">'
        +'<select  class="custom-select" name="estado[]">'
        +'<option '+sel1+' value="Acre">Acre</option>'
        +'<option '+sel2+' value="Alagoas">Alagoas</option>'
        +'<option '+sel3+'  value="Amapa">Amap&aacute;</option>'
        +'<option '+sel4+'  value="Amazonas">Amazonas</option>'
        +'<option '+sel5+'  value="Bahia">Bahia</option>'
        +'<option '+sel6+'  value="Ceara">Cear&aacute;</option>'
        +'<option '+sel7+'  value="Distrito Federal">Distrito Federal</option>'
        +'<option '+sel8+'  value="Espirito Santo">Esp&iacute;rito Santo</option>'
        +'<option '+sel9+'  value="Goias">Goi&aacute;s</option>'
        +'<option '+sel10+'  value="Maranhao">Maranh&atilde;o</option>'
        +'<option '+sel11+'  value="Mato Grosso">Mato Grosso</option>'
        +'<option '+sel12+'  value="Mato Grosso do Sul">Mato Grosso do Sul</option>'
        +'<option '+sel13+'  value="Minas Gerais">Minas Gerais</option>'
        +'<option '+sel14+'  value="Para">Par&aacute;</option>'
        +'<option '+sel15+'  value="Paraiba">Para&iacute;ba</option>'
        +'<option '+sel16+'  value="Parana">Paran&aacute;</option>'
        +'<option '+sel17+'  value="Pernambuco">Pernambuco</option>'
        +'<option '+sel18+'  value="Piaui">Piau&iacute;</option>'
        +'<option '+sel19+'  value="Rio de Janeiro">Rio de Janeiro</option>'
        +'<option '+sel20+'  value="Rio Grande do Norte">Rio Grande do Norte</option>'
        +'<option '+sel21+'  value="Rio Grande do Sul">Rio Grande do Sul</option>'
        +'<option '+sel22+'  value="Rondonia">Rond&ocirc;nia</option>'
        +'<option '+sel23+'  value="Roraima">Roraima</option>'
        +'<option '+sel24+'  value="Santa Catarina">Santa Catarina</option>'
        +'<option '+sel25+'  value="Sao Paulo">S&atilde;o Paulo</option>'
        +'<option '+sel26+'  value="Sergipe">Sergipe</option>'
        +'<option '+sel27+'  value="Tocantins">Tocantins</option>'
        +'</select>'
        +'</div>'
        +'</div>'
        +'<div class="col-sm-4 nopadding" style="margin-top:10px">'
        +'<div class="form-group" >'
        +'<input name="group1[]" onclick="muda_valor('+room+')" style="left: 0px" type="radio" id="radio_'+room+'" value="0" >' 
        +'<label for="radio_'+room+'">Seu endere&ccedil;o principal?</label>'
        +'</div>'
        +'</div>'
        +'<div class="col-sm-1 nopadding" style="margin-top:10px" >'
        +'<div class="form-group">'        
        +'<button id="botao_enderecos'+room+'" class="btn btn-danger"  type="button" onclick="remove_education_fields(' + room + ','+logradouro_reverse_aux+');"> <i class="fa fa-minus"></i>   '
        +'</button>'
        +'</div>'
        +'</div>'
        +'</div>'
        +'</div>'
        +'</div>'
        +'</div>'
        objTo.appendChild(divtest);

        var i_i = i + 2; 
        var pos_id = 'botao_enderecos'+i_i;
        
        document.getElementById(pos_id).setAttribute('onclick','remove_education_fields('+i_i+',"'+logradouro_reverse[i]+'")');
    } 
    conta++;
}
</script>




<!-- Fechando as divs e o body do header -- >
</div>    
</div>
</div>


<script src="../assets/plugins/jquery/jquery.min.js"></script>
<script src="../assets/plugins/switchery/dist/switchery.min.js"></script>
    
   
</body>

<!-- Chamando o footer.blade.php que contem as chamadas do js e o footer -->
@include('footer')
<script src="../assets/plugins/bootstrap-select/bootstrap-select.min.js" type="text/javascript"></script>
<script src="../js/mask.js"></script>
<script src="../assets/plugins/typeahead.js-master/dist/typeahead.bundle.min.js"></script>
<script src="../assets/plugins/typeahead.js-master/dist/typeahead-init.js"></script>