<!DOCTYPE html>
<html lang="en">

<!-- Chamando o header.blade.php que contem as chamadas do css e o header -->

@include('header_index')



<div class="row">
    <div class="col-10">
        <div class="card card-body" style=" left:50px; margin-top: 80px;">
            <h3 class="box-title m-b-0">Adicionar filmes</h3>
            <p class="text-muted m-b-30 font-13"> Insira as informa&ccedil;&otilde;es abaixo </p>
            
            <div class="row">
                <div class="col-sm-12 col-xs-12">
                    
                    <form class="floating-labels m-t-40">
                        
                        
                       
                        <!-- div dos filmes -->
                        <div class="card">
                            <div class="card-body">
                                <h4 class="card-title">Filmes:</h4>
                                <div class="row">
                                    <div class="col-sm-2 nopadding">
                                        <div class="form-group">
                                            <input type="text" class="form-control" id="titulo" name="titulo[]" value="" placeholder="Titulo do filme">
                                            <input type="hidden" name="_token" value="{{csrf_token()}}">

                                        </div>
                                    </div>
                                    <div class="col-sm-2 nopadding">
                                        <div class="form-group">
                                            <input type="text" class="form-control" id="ano" name="ano[]" value="" placeholder="Ano de lancamento">
                                        </div>
                                    </div>
                                    <div class="col-sm-2 nopadding">
                                        <div class="form-group">
                                            <input type="text" class="form-control" id="diretor" name="diretor[]" value="" placeholder="Diretor">
                                        </div>
                                    </div>
                                    <div class="col-sm-2 nopadding">
                                        <div class="form-group">
                                            <input type="text" class="form-control" id="nota_do_filme" name="nota_do_filme[]" value="" placeholder="Nota do filme">
                                        </div>
                                    </div>
                                    <div class="col-sm-2 nopadding">
                                        <div class="form-group">
                                            <input type="text" class="form-control" id="sinopse_do_filme" name="sinopse_do_filme[]" value="" placeholder="Sinopse do filme">
                                        </div>
                                    </div>
                                    <div class="col-sm-1 nopadding" style="margin-top:10px" >
                                        <div class="form-group">        
                                            <button class="btn btn-success" type="button" onclick="filme_adicional();"><i class="fa fa-plus"></i></button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- div dos filmes -->
                         <!-- div de enderecos adicionais -->
                        <div id="filme_adicional"></div>
                        <!-- div de enderecos adicionais -->
                        
            
            <div class="form-group">
                            <button type="submit"  id="cadastrar" formmethod="post" class="btn btn-success waves-effect waves-light m-r-10">Salvar</button>
                            <button type="button" onclick="voltar();" class="btn btn-inverse waves-effect waves-light">Voltar</button>
                            <a href="/index" style="display:none" id="ex">Triggerable link</a>
                        </div>
                    </form>
                </div>
            </div>

            



        </div>
    </div>
</div>


<script>
    function voltar(){
        $('#ex').click();
        location.href=$('#ex').attr('href');
    }
</script>


<script type="text/javascript">
    var room_filme = 1;
    var conta_filme  = 0;
    var conta_2_filme = 0;

    var titulo_antigo = [];
    var ano_antigo  = [];
    var diretor_antigo  = [];
    var nota_do_filme_antigo = [];
    var sinopse_do_filme_antigo = [];
    var excluir_filme = 0;
    function filme_adicional(){
        var posicao = 0;
        var elemento1 = document.getElementsByName('titulo[]');
        var elemento2 = document.getElementsByName('ano[]');
        var elemento3 = document.getElementsByName('diretor[]');
        var elemento4 = document.getElementsByName('nota_do_filme[]');
        var elemento5 = document.getElementsByName('sinopse_do_filme[]');
        if(elemento1[posicao].value !== ""){
        var valor1 = elemento1[posicao].value;
        }else{
            var valor1 = "";
        }

        if(elemento2[posicao].value !== ""){
            var valor2 = elemento2[posicao].value;
        }else{
            var valor2 = "";
        }

        if(elemento3[posicao].value !== ""){
            var valor3 = elemento3[posicao].value;
        }else{
            var valor3 = "";
        }

        if(elemento4[posicao].value !== ""){
            var valor4 = elemento4[posicao].value;
        }else{
            var valor4 = "";
        }
        if(elemento5[posicao].value !== ""){
            var valor5 = elemento5[posicao].value;
        }else{
            var valor5 = "";
        }
        elemento1[posicao].value="";
        elemento2[posicao].value="";
        elemento3[posicao].value="";
        elemento4[posicao].value="";
        elemento5[posicao].value="";
        elemento1[posicao].focus();
        if( (valor1 !== "") && (valor2 !== "") && (valor3 !== "")  && (valor5 !== "") ){
            titulo_antigo[conta_2_filme] = valor1;
            ano_antigo[conta_2_filme]  = valor2;
            diretor_antigo[conta_2_filme]  = valor3;
            nota_do_filme_antigo[conta_2_filme] = valor4;
            sinopse_do_filme_antigo[conta_2_filme] = valor5;


            room_filme++;
            var objTo = document.getElementById('filme_adicional');
            var divtest = document.createElement("div");
            divtest.setAttribute("class", "form-group removeclass_filme" + room_filme);

                                    
                                        
                                    
                                    
                                

            var rdiv = 'removeclass_filme' + room_filme;

            var valor1_aux = "'"+valor1+"'";        
            divtest.innerHTML = '<div class="card">'
            +'<div class="card-body">'
            +'<h4 class="card-title">Filmes:</h4>'
            +'<div class="row">'
            +'<div class="col-sm-2 nopadding">'
            +'<div class="form-group">'
            +'<input type="text" class="form-control" id="titulo" name="titulo[]" value="'+valor1+'" placeholder="Titulo do filme">'
            +'</div>'
            +'</div>'
            +'<div class="col-sm-2 nopadding">'
            +'<div class="form-group">'
            +'<input type="text" class="form-control" id="ano" name="ano[]" value="'+valor2+'" placeholder="Ano de lancamento">'
            +'</div>'
            +'</div>'
            +'<div class="col-sm-2 nopadding">'
            +'<div class="form-group">'
            +'<input type="text" class="form-control" id="diretor" name="diretor[]" value="'+valor3+'" placeholder="Diretor">'
            +'</div>'
            +'</div>'
            +'<div class="col-sm-2 nopadding">'
            +'<div class="form-group">'
            +'<input type="text" class="form-control" id="nota_do_filme" name="nota_do_filme[]" value="'+valor4+'" placeholder="Nota do filme">'
            +'</div>'
            +'</div>'
            +'<div class="col-sm-2 nopadding">'
            +'<div class="form-group">'
            +'<input type="text" class="form-control" id="sinopse_do_filme" name="sinopse_do_filme[]" value="'+valor5+'" placeholder="Sinopse do filme">'
            +'</div>'
            +'</div>'
            +'<div class="col-sm-1 nopadding" style="margin-top:10px" >'
            +'<div class="form-group">'        
            +'<button id="botao_filmes'+room_filme+'" class="btn btn-danger"  type="button" onclick="remove_education_fields_filme(' + room_filme + ','+valor1_aux+');"> <i class="fa fa-minus"></i>   '
            +'</button>'
            +'</div>'
            +'</div>'
            +'</div>'
            +'</div>'
            objTo.appendChild(divtest);

            var titulo  = document.getElementsByName('titulo[]');
            var ano  = document.getElementsByName('ano[]');
            var diretor  = document.getElementsByName('diretor[]');
            var nota_do_filme = document.getElementsByName('nota_do_filme[]');
            var sinopse_do_filme = document.getElementsByName('sinopse_do_filme[]');

            var troca = "";

            var tam_titulo = titulo.length;

            
            var titulo_reverse = [];
            var ano_reverse  = [];
            var diretor_reverse  = [];
            var nota_do_filme_reverse = [];
            var sinopse_do_filme_reverse = [];


            titulo_reverse = titulo_antigo.slice();
            ano_reverse  = ano_antigo.slice(); 
            diretor_reverse  = diretor_antigo.slice(); 
            nota_do_filme_reverse = nota_do_filme_antigo.slice(); 
            sinopse_do_filme_reverse = sinopse_do_filme_antigo.slice(); 

            
            titulo_reverse.reverse();
            ano_reverse.reverse();
            diretor_reverse.reverse();
            nota_do_filme_reverse.reverse();
            sinopse_do_filme_reverse.reverse();



            j = 0;
            for(var i = 1; i < tam_titulo; i++){
                titulo[i].value  = titulo_reverse[j];
                ano[i].value  = ano_reverse[j];
                diretor[i].value = diretor_reverse[j];
                nota_do_filme[i].value  = nota_do_filme_reverse[j];
                sinopse_do_filme[i].value  = sinopse_do_filme_reverse[j];



                var i_i = i + 1; 

                var pos_id = 'botao_filmes'+i_i;
                document.getElementById(pos_id).setAttribute('onclick','remove_education_fields_filme('+i_i+',"'+titulo_reverse[j]+'")');



                j++;
            }
            conta_2_filme++;
        }else{
            alert('preencha todos os campos');
        }
    }
function remove_education_fields_filme(rid,valor1_funcao) {

    var posicao_remove = 0;
    posicao_remove = titulo_antigo.indexOf(valor1_funcao);
    titulo_antigo.splice(posicao_remove,1);
    ano_antigo.splice(posicao_remove,1);    
    diretor_antigo.splice(posicao_remove,1);    
    nota_do_filme_antigo.splice(posicao_remove,1);
    sinopse_do_filme_antigo.splice(posicao_remove,1);    


    var education_fields = document.getElementById('filme_adicional');
    while(education_fields.firstChild){
        education_fields.removeChild(education_fields.firstChild);
    }

    conta_2_filme--;
    room_filme = 1;

    titulo_reverse = titulo_antigo.slice();
    ano_reverse  = ano_antigo.slice(); 
    diretor_reverse  = diretor_antigo.slice(); 
    nota_do_filme_reverse = nota_do_filme_antigo.slice(); 
    sinopse_do_filme_reverse = sinopse_do_filme_antigo.slice(); 


    titulo_reverse.reverse();
    ano_reverse.reverse();
    diretor_reverse.reverse();
    nota_do_filme_reverse.reverse();
    sinopse_do_filme_reverse.reverse();


    var tamanho_reverse = titulo_reverse.length;
    for(var i = 0; i < tamanho_reverse; i++){

        room_filme++;
        var objTo = document.getElementById('filme_adicional')
        var divtest = document.createElement("div");
        divtest.setAttribute("class", "form-group removeclass_filme" + room_filme);
        var rdiv = 'removeclass_filme' + room_filme;
        
        var titulo_reverse_aux = "'"+titulo_reverse[i]+"'";
        divtest.innerHTML = '<div class="card">'
            +'<div class="card-body">'
            +'<h4 class="card-title">Filmes:</h4>'
            +'<div class="row">'
            +'<div class="col-sm-2 nopadding">'
            +'<div class="form-group">'
            +'<input type="text" class="form-control" id="titulo" name="titulo[]" value="'+titulo_reverse[i]+'" placeholder="Titulo do filme">'
            +'</div>'
            +'</div>'
            +'<div class="col-sm-2 nopadding">'
            +'<div class="form-group">'
            +'<input type="text" class="form-control" id="ano" name="ano[]" value="'+ano_reverse[i]+'" placeholder="Ano de lancamento">'
            +'</div>'
            +'</div>'
            +'<div class="col-sm-2 nopadding">'
            +'<div class="form-group">'
            +'<input type="text" class="form-control" id="diretor" name="diretor[]" value="'+diretor_reverse[i]+'" placeholder="Diretor">'
            +'</div>'
            +'</div>'
            +'<div class="col-sm-2 nopadding">'
            +'<div class="form-group">'
            +'<input type="text" class="form-control" id="nota_do_filme" name="nota_do_filme[]" value="'+nota_do_filme_reverse[i]+'" placeholder="Nota do filme">'
            +'</div>'
            +'</div>'
            +'<div class="col-sm-2 nopadding">'
            +'<div class="form-group">'
            +'<input type="text" class="form-control" id="sinopse_do_filme" name="sinopse_do_filme[]" value="'+sinopse_do_filme_reverse[i]+'" placeholder="Sinopse do filme">'
            +'</div>'
            +'</div>'
            +'<div class="col-sm-1 nopadding" style="margin-top:10px" >'
            +'<div class="form-group">'        
            +'<button id="botao_filmes'+room_filme+'" class="btn btn-danger"  type="button" onclick="remove_education_fields_filme(' + room_filme + ','+titulo_reverse_aux+');"> <i class="fa fa-minus"></i>   '
            +'</button>'
            +'</div>'
            +'</div>'
            +'</div>'
            +'</div>'
        objTo.appendChild(divtest);

        var i_i = i + 2; 
        var pos_id = 'botao_filmes'+i_i;

        document.getElementById(pos_id).setAttribute('onclick','remove_education_fields_filme('+i_i+',"'+titulo_reverse[i]+'")');
    } 
    conta_filme++;
}
</script>






<!-- Fechando as divs e o body do header -- >
</div>    
</div>
</div>


<script src="../assets/plugins/jquery/jquery.min.js"></script>
<script src="../assets/plugins/switchery/dist/switchery.min.js"></script>
    
   
</body>

<!-- Chamando o footer.blade.php que contem as chamadas do js e o footer -->
@include('footer')


<script src="../assets/plugins/bootstrap-select/bootstrap-select.min.js" type="text/javascript"></script>
<script src="../js/mask.js"></script>
<script src="../assets/plugins/typeahead.js-master/dist/typeahead.bundle.min.js"></script>
<script src="../assets/plugins/typeahead.js-master/dist/typeahead-init.js"></script>