var room = 1;
var aux = 0;

function education_fields() {
    var posicao = 0;
    posicao  = room - aux -1;
	var elemento = document.getElementsByName('protocolo[]');
    var ano = document.getElementsByName('ano[]');
	if (elemento[posicao].value!= ""){
     var valor = elemento[posicao].value;
    }
	else{
     var valor = "";
    }
    if (ano[posicao].value!= ""){
     var valor_ano = ano[posicao].value;
    }
    else{
     var valor_ano = "";
    }
	elemento[posicao].value = ""; 
	elemento[posicao].focus();
    room++;
    var objTo = document.getElementById('education_fields');
    var divtest = document.createElement("div");
                                            
    divtest.setAttribute("class", "form-group removeclass" + room);
    var rdiv = 'removeclass' + room;
    
         
    divtest.innerHTML = '<div class="row"><div class="col-sm-5 nopadding"><div class="form-group"> <input type="text" class="form-control" id="protocolo" name="protocolo[]" value="'+valor+'" placeholder="protocolo"></div></div><div class="col-sm-3 nopadding" style="margin-top:10px"><div class="form-group"><select class="custom-select" name="ano[]"><option value="2005">2005</option><option value="2006">2006</option><option value="2007">2007</option><option value="2008">2008</option><option value="2009">2009</option><option value="2010">2010</option><option value="2011">2011</option><option value="2012">2012</option><option value="2013">2013</option><option value="2014">2014</option><option value="2015">2015</option><option value="2016">2016</option><option value="2017">2017</option><option value="2018">2018</option></select></div></div><div class="col-sm-3" style="margin-top:20px"><span name="marcador_nome[]">Ambiental</span><input type="hidden" name="marcador_valor[]" value="1"><input type="checkbox" class="js-switch"  name="marcador_checker[]" value="2"  onchange="desmarca('+posicao+');" data-color="#26c6da" data-size="small" data-secondary-color="#f62d51"></div><div class="col-sm-1 nopadding" style="right:40px;margin-top:10px"><div class="form-group"><div class="input-group"> <div class="input-group-append"> <button class="btn btn-danger" type="button" onclick="remove_education_fields(' + room + ');"> <i class="fa fa-minus"></i> </button></div></div></div></div><div class="demo-radio-button"><div>Notificar sobre o protocolo a cada: </div><input name="group'+posicao+'" value="5" type="radio" id="radio_1_'+posicao+'" checked /><label for="radio_1_'+posicao+'">5 dias</label><input name="group'+posicao+'" value="15" type="radio" id="radio_2_'+posicao+'" /><label for="radio_2_'+posicao+'">15 dias</label><input name="group'+posicao+'" value="30" type="radio" id="radio_3_'+posicao+'" /><label for="radio_3_'+posicao+'">30 dias</label></div></div><div>--------------------------------------------------------------------------------------------------------------------------------------</div>';
    objTo.appendChild(divtest);
    var ano = document.getElementsByName('ano[]');
    ano[posicao].value =   valor_ano ; 

    var marcador_checker = document.getElementsByName('marcador_checker[]');
    $('.js-switch').each(function() {
            new Switchery($(this)[0], $(this).data());
    });
    marcador_checker[posicao].value = "chamado";
      
}

function remove_education_fields(rid) {
    $('.removeclass' + rid).remove();
    aux ++;
}