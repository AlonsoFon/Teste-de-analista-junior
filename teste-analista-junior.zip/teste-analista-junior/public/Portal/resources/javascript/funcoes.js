
function mask(campo, Mascara, evento) { 
	var boleanoMascara; 
	var Digitato = evento.keyCode;
	exp = /\-|\.|\/|\(|\)| /g
	campoSoNumeros = campo.value.toString().replace( exp, "" ); 
	var posicaoCampo = 0;    
	var NovoValorCampo="";
	var TamanhoMascara = campoSoNumeros.length;; 
	if (Digitato != 8) { // backspace
	for(i=0; i<= TamanhoMascara; i++) {
		boleanoMascara  = ((Mascara.charAt(i) == "-") || (Mascara.charAt(i) == ".") || (Mascara.charAt(i) == "/"))
		boleanoMascara  = boleanoMascara || ((Mascara.charAt(i) == "(") || (Mascara.charAt(i) == ")") || (Mascara.charAt(i) == " "))
		if (boleanoMascara) {
			NovoValorCampo += Mascara.charAt(i);
			TamanhoMascara++;
		}else {
			NovoValorCampo += campoSoNumeros.charAt(posicaoCampo);
			posicaoCampo++;
		}              
	}      
	campo.value = NovoValorCampo;
	return true; 
	}else { 
	        return true; 
	}
}

function soNumero(event, input) {
	var key = getKeyEvent(event);
	if (isTeclaControl(event) && (key == 99 || key == 118 || key == 120))
		return true;
	if (key == 13)
		return disableEnterKey(event, input);
	if (key == 0 || key == 8 || (key >= 48 && key <= 58)) {
		return true;
	}
	return false;
}

function getKeyEvent(event) {
	if (window.event) {
		return window.event.keyCode;
	}
	return event.which;
}

function isTeclaControl(event) {
	if (window.event) {
		return window.event.ctrlKey;
	}
	return event.ctrlKey;
}




