<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/



//*** FUNCOES DO LARAVEL

// chamada quando o usuario digita /login no browser
Route::get('/login', 'UsuariosController@login');


// chamada quando o usuario efetua seu login na pagina de login
Route::post('/login', 'UsuariosController@logar');


// chamada quando o usuario digita /cadastro no browser ou quando o usuario clica no botao cadastrar do login
Route::get('/cadastro', 'UsuariosController@cadastro');

// chamada quando o usuario clica no botao cadastrar da tela de cadastro
Route::post('/cadastro','UsuariosController@cadastrar');

// chamada quando o usuario digitar /protocolo_arquivado no browser, se ele tiver feito um login recente irá para a view protocolo_arquivado, se nao redireciona para a view login
Route::get('/index', 'UsuariosController@index');



// chamada quando o usuario efetuar o logout no index
Route::get('/logout', 'UsuariosController@logout');

// chamada quando o usuario for nas configs e clicar na pagina alterar senha
Route::get('/alterar_senha', 'UsuariosController@alterar_senha');

// chamada quando o usuario salvar alterar senha
Route::post('/alterar_senha', 'UsuariosController@salvar_alterar_senha');

// chamada quando o usuario for nas configs e clicar pagina de editar perfil
Route::get('/editar_perfil', 'UsuariosController@editar_perfil');

// chamada quando o usuario salvar a edicao de perfil
Route::post('/editar_perfil', 'UsuariosController@salvar_editar_perfil');


// chamada quando o usuario for na dashboard e clicar em adicionar enderecos
Route::get('/adicionar_enderecos', 'UsuariosController@adicionar_enderecos');

// chamada quando o usuario salvar a adicao de enderecos
Route::post('/adicionar_enderecos', 'UsuariosController@salvar_adicionar_enderecos');

// chamada quando o usuario for na dashboard e clicar em adicionar filmes
Route::get('/adicionar_filmes', 'UsuariosController@adicionar_filmes');

// chamada quando o usuario salvar a adicao de filmes
Route::post('/adicionar_filmes', 'UsuariosController@salvar_adicionar_filmes');



// chamada quando o usuario digitar / no browser, se ele tiver feito um login recente irá para a view index, se nao redireciona para a view login
Route::get('/', 'UsuariosController@index');
