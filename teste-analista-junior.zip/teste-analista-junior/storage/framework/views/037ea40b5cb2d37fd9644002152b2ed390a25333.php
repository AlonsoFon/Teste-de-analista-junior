<!DOCTYPE html>
<html lang="en">


<!-- Chamando o header.blade.php que contem as chamadas do css e o header -->
<?php echo $__env->make('header_index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php if(session('alert')): ?>
    <div class="alert alert-success">
        <?php echo e(session('alert')); ?>

    </div>
<?php endif; ?>

<!-- Incluindo o model usuario para poder manipular o banco e preparando os protocolos e o ano -->
<?php 
    use App\Produto;
	$Produto = Produto::all();
    $nome = array();
    $descricao = array();
    $valor = array();
    $quantidade = array();
    $duracao = array();
    
    foreach($Produto as $row){
    	
    	$nome[] = $row->nome;
        $id[] = $row->id;
    	$descricao[] = $row->descricao;
        $valor[] = $row->valor;
        $quantidade[] = $row->quantidade;
        $duracao[] = $row->duracao;
    	
    } 
    
    $tamanho = count($nome);
?>

<div class="row">
                    <!-- Column -->
                    <div class="col-lg-7 col-md-12">
                        <div class="card" style="left:350px; margin-top:20px;">
                            <div class="card-body" >
                                <div class="d-flex no-block">
                                    <h4 class="card-title">Produtos cadastrados</h4><div class="ml-auto">
                                    <button type="button" onclick="novo();" class="btn btn-info btn-rounded">Novo produto </button>
                                    </div>
                                    <!-- div do select para selecionar a ordenação (qlq coisa)
                                    <div class="ml-auto">
                                        <select class="custom-select">
                                            <option selected="">Electronics</option>
                                            <option value="1">Kitchen</option>
                                            <option value="2">Crocory</option>
                                            <option value="3">Wooden</option>
                                        </select>
                                    </div>
                                	-->
                                </div>
                                <div class="table-responsive">
                                    <table class="table stylish-table">
                                        <thead>
                                            <tr>
                                                <th>Nome</th>
                                                <th>Valor</th>
                                                <th>Quantidade</th>
                                                <th>Duração</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                        	<?php
                                        	for ($i = 0; $i < $tamanho ; $i++){
                                            if($duracao[$i] == "3") $aux = "3 meses";
                                            if($duracao[$i] == "6") $aux = "6 meses";
                                            if($duracao[$i] == "12") $aux = "1 ano";
                                        	echo "<tr>";
                                        		echo "<td>";
                                        			echo "<h6>".$nome[$i]."</h6><small class=\"text-muted\">".$descricao[$i]." </small>";
                                        		echo "</td>";
                                        		echo "<td>";
                                        			echo "<h5>".$valor[$i]."</h5>";
                                        		echo "</td>";
                                                echo "<td>";
                                                    echo "<h5>".$quantidade[$i]."</h5>";
                                                echo "</td>";
                                                echo "<td>";
                                                echo "<h5>".$aux."</h5>";
                                                echo "</td>";
                                                echo "<td>";
                                                echo "<button type=\"button\" onclick=\"editarproduto('".$nome[$i]."','".$descricao[$i]."','".$id[$i]."','".$valor[$i]."','".$quantidade[$i]."','".$duracao[$i]."');\" class=\"btn btn-success waves-effect waves-light m-r-10\">Editar</button> ";
                                                echo "</td>";
                                                  echo "<td>";
                                                echo "<button type=\"button\" onclick=\"excluirproduto('".$nome[$i]."','".$id[$i]."','".$valor[$i]."','".$quantidade[$i]."','".$duracao[$i]."');\" class=\"btn btn-inverse waves-effect waves-light m-r-10\">Excluir</button> ";
                                                echo "</td>";

                                                
                                        	echo "</tr>";
                        
                                            }
                                        	?>
                            <form id="excluir_produto" action="/excluir_produto" method="post">
                                <input type="hidden" name="nome_produto" value="">
                                <input type="hidden" name="id_produto" value="">
                                <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                                <input type="hidden"  name="valor_produto" value="">
                                <input type="hidden"  name="quantidade_produto" value="0">
                                <input type="hidden"  name="duracao_produto" value="0">
                            </form>
                            <form id="editar_produto" action="/editar_produto" method="post">
                                <input type="hidden" name="nome_produto2" value="">
                                <input type="hidden" name="id_produto2" value="">
                                <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                                <input type="hidden"  name="valor_produto2" value="">
                                <input type="hidden"  name="quantidade_produto2" value="0">
                                <input type="hidden"  name="descricao_produto2" value="0">
                                <input type="hidden"  name="duracao_produto2" value="0">
                            </form>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                </div>



<div class="form-group" align ="Center">
    <button type="button" id="botaovoltar" style="width:150px;" onclick="voltar();" class="btn btn-inverse waves-effect waves-light">Voltar</button>
    <a href="/index" style="display:none" id="ex">Triggerable link</a>
    <a href="/produtos" style="display:none" id="novo">Triggerable link</a>
</div>

<script>
    function voltar(){
        $('#ex').click();
        location.href=$('#ex').attr('href');
    }
</script>

<script>
    function novo(){
        $('#novo').click();
        location.href=$('#novo').attr('href');
    }
</script>

<script>
    function excluirproduto(nome,id,valor,quantidade,duracao){
        
        document.getElementsByName('id_produto')[0].value = id;
        document.getElementsByName('nome_produto')[0].value = nome;
        document.getElementsByName('valor_produto')[0].value = valor;
        document.getElementsByName('quantidade_produto')[0].value = quantidade;
        document.getElementsByName('duracao_produto')[0].value = duracao;
        document.getElementById("excluir_produto").submit();
    }
</script>

<script>
    function editarproduto(nome,descricao,id,valor,quantidade,duracao){
        
        document.getElementsByName('id_produto2')[0].value = id;
        document.getElementsByName('nome_produto2')[0].value = nome;
        document.getElementsByName('valor_produto2')[0].value = valor;
        document.getElementsByName('quantidade_produto2')[0].value = quantidade;
        document.getElementsByName('duracao_produto2')[0].value = duracao;
        document.getElementsByName('descricao_produto2')[0].value = descricao;
        document.getElementById("editar_produto").submit();
    }
</script>


<!-- Fechando as divs e o body do header -->


</div>
</div>
</div>


</body>
<!-- Chamando o footer.blade.php que contem as chamadas do js e o footer -->
<?php echo $__env->make('footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>