<!DOCTYPE html>
<html lang="en">

<!-- Chamando o header.blade.php que contem as chamadas do css e o header -->

<?php echo $__env->make('header_index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php 
    use App\Protocolo;
    $Protocolo = Protocolo::all();
    foreach($Protocolo as $row){
        if( ($email == $row->email) && ($protocolo == $row->protocolo) && ($ano == $row->ano) && ($tipo == $row->tipo) ){
            $protocolo_alt = $row->protocolo;
            $ano_alt = $row->ano;
            $tipo_alt = $row->tipo;
            $descricao_alt = $row->descricao;
        }
    }
 ?>

<div class="row">
    <div class="col-10">
        <div class="card card-body" style=" left:115px; margin-top: 20px;">
            <h3 class="box-title m-b-0">Editar protocolo</h3>
            <p class="text-muted m-b-30 font-13"> Insira suas informações abaixo </p>
            
            <div class="row">
                <div class="col-sm-12 col-xs-12">
                	
                    <form class="floating-labels m-t-40"
class="floating-labels m-t-40" action="salvar_edicao_protocolo" method="post">
                        <!-- div dos protocolos -->
                        <div class="card">
                            <div class="card-body">
                                <h4 class="card-title">Descri&ccedil;&atilde;o do protocolo</h4>
                                <div id="education_fields"></div>
                                <div class="row">
                                    <div class="col-sm-12 nopadding">
                                        <div class="form-group">
                                            <input type="text" class="form-control" id="protocolo" name="descricao" value="<?php echo e($descricao_alt); ?>" placeholder="descricao do protocolo">
                                            <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                                            <input type="hidden"  name="protocolo_antigo" value="<?php echo e($protocolo_alt); ?>">
                                            <input type="hidden"  name="ano_antigo" value="<?php echo e($ano_alt); ?>">
                                            <input type="hidden"  name="tipo_antigo" value="<?php echo e($tipo_alt); ?>">
                                        </div>
                                    </div>
                                    
                                    
                                </div>
                                </div>
                            </div>
                        </div>  
                        <!-- div dos protocolos -->
                        <div class="form-group">
                        <button type="submit" class="btn btn-success waves-effect waves-light">Editar</button>
                        <button type="button" onclick="voltar();" class="btn btn-inverse waves-effect waves-light">Voltar</button>
                        <a href="/index" style="display:none" id="ex">Triggerable link</a>
                       
                        </div>
                        <div class="col-md-4 m-b-30">
                                        <div class="example">
                                            <h5 class="box-title">Simple mode</h5>
                                            <p class="text-muted m-b-20">just add class <code>.colorpicker</code> to create it.</p>
                                            <input type="text" class="colorpicker form-control" value="#7ab2fa" /> 
                                        </div>
                                    </div>
                    </form>
                </div>
            </div>

            



        </div>
    </div>
</div>


<script>
	function voltar(){
		$('#ex').click();
		location.href=$('#ex').attr('href');
	}
</script>







<!-- chamada do Javascript da div dinamida dos protocolos -->
<script src="../assets/plugins/dff/dff.js" type="text/javascript"></script>



<!-- Fechando as divs e o body do header -- >
</div>    
</div>
</div>


<!-- ============================================================== -->
    <!-- End Wrapper -->
    <!-- ============================================================== -->
    <!-- ============================================================== -->
    <!-- All Jquery -->
    <!-- ============================================================== -->
    <script src="../assets/plugins/jquery/jquery.min.js"></script>
    <!-- Bootstrap tether Core JavaScript -->
    
    
    <!-- Plugin JavaScript -->
            <script src="../assets/plugins/moment/moment.js"></script>
            <script src="../assets/plugins/bootstrap-material-datetimepicker/js/bootstrap-material-datetimepicker.js"></script>
            <!-- Clock Plugin JavaScript -->
            <script src="../assets/plugins/clockpicker/dist/jquery-clockpicker.min.js"></script>
            <!-- Color Picker Plugin JavaScript -->
            <script src="../assets/plugins/jquery-asColorPicker-master/libs/jquery-asColor.js"></script>
            <script src="../assets/plugins/jquery-asColorPicker-master/libs/jquery-asGradient.js"></script>
            <script src="../assets/plugins/jquery-asColorPicker-master/dist/jquery-asColorPicker.min.js"></script>
            <!-- Date Picker Plugin JavaScript -->
            <script src="../assets/plugins/bootstrap-datepicker/bootstrap-datepicker.min.js"></script>
            <!-- Date range Plugin JavaScript -->
            <script src="../assets/plugins/timepicker/bootstrap-timepicker.min.js"></script>
            <script src="../assets/plugins/bootstrap-daterangepicker/daterangepicker.js"></script>
            <script>
            // MAterial Date picker    
            $('#mdate').bootstrapMaterialDatePicker({
                weekStart: 0,
                time: false
            });
            $('#timepicker').bootstrapMaterialDatePicker({
                format: 'HH:mm',
                time: true,
                date: false
            });
            $('#date-format').bootstrapMaterialDatePicker({
                format: 'dddd DD MMMM YYYY - HH:mm'
            });

            $('#min-date').bootstrapMaterialDatePicker({
                format: 'DD/MM/YYYY HH:mm',
                minDate: new Date()
            });
            // Clock pickers
            $('#single-input').clockpicker({
                placement: 'bottom',
                align: 'left',
                autoclose: true,
                'default': 'now'
            });
            $('.clockpicker').clockpicker({
                donetext: 'Done',
            }).find('input').change(function() {
                console.log(this.value);
            });
            $('#check-minutes').click(function(e) {
                // Have to stop propagation here
                e.stopPropagation();
                input.clockpicker('show').clockpicker('toggleView', 'minutes');
            });
            if (/mobile/i.test(navigator.userAgent)) {
                $('input').prop('readOnly', true);
            }
            // Colorpicker
            $(".colorpicker").asColorPicker();
            $(".complex-colorpicker").asColorPicker({
                mode: 'complex'
            });
            $(".gradient-colorpicker").asColorPicker({
                mode: 'gradient'
            });
            // Date Picker
            jQuery('.mydatepicker, #datepicker').datepicker();
            jQuery('#datepicker-autoclose').datepicker({
                autoclose: true,
                todayHighlight: true
            });
            jQuery('#date-range').datepicker({
                toggleActive: true
            });
            jQuery('#datepicker-inline').datepicker({
                todayHighlight: true
            });
            // Daterange picker
            $('.input-daterange-datepicker').daterangepicker({
                buttonClasses: ['btn', 'btn-sm'],
                applyClass: 'btn-danger',
                cancelClass: 'btn-inverse'
            });
            $('.input-daterange-timepicker').daterangepicker({
                timePicker: true,
                format: 'MM/DD/YYYY h:mm A',
                timePickerIncrement: 30,
                timePicker12Hour: true,
                timePickerSeconds: false,
                buttonClasses: ['btn', 'btn-sm'],
                applyClass: 'btn-danger',
                cancelClass: 'btn-inverse'
            });
            $('.input-limit-datepicker').daterangepicker({
                format: 'MM/DD/YYYY',
                minDate: '06/01/2015',
                maxDate: '06/30/2015',
                buttonClasses: ['btn', 'btn-sm'],
                applyClass: 'btn-danger',
                cancelClass: 'btn-inverse',
                dateLimit: {
                    days: 6
                }
            });
            </script>
    <!-- ============================================================== -->
    <!-- This page plugins -->
    <!-- ============================================================== -->
    <script src="../assets/plugins/switchery/dist/switchery.min.js"></script>
    
   
</body>

<!-- Chamando o footer.blade.php que contem as chamadas do js e o footer -->
<?php echo $__env->make('footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<script src="../assets/plugins/bootstrap-select/bootstrap-select.min.js" type="text/javascript"></script>
<script src="js/mask.js"></script>
<script src="../assets/plugins/typeahead.js-master/dist/typeahead.bundle.min.js"></script>
<script src="../assets/plugins/typeahead.js-master/dist/typeahead-init.js"></script>