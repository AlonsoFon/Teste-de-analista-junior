<!DOCTYPE html>
<html lang="en">


<!-- Chamando o header.blade.php que contem as chamadas do css e o header -->
<?php echo $__env->make('header_index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php if(session('alert')): ?>
    <div class="alert alert-success">
        <?php echo e(session('alert')); ?>

    </div>
<?php endif; ?>

<!-- Incluindo o model usuario para poder manipular o banco e preparando os protocolos e o ano -->
<?php 
// funcao do push
function sendMessage(){

        $content = array(
            "en" => 'Esta eh uma msg de ate 100 caracteres'
            );
        $Headings = array(
            "en" => 'Esse eh um titulo'
            );
        $fields = array(
            'app_id' => "04d9a36d-4ec7-4b51-9ad2-7e4664417186",
            'include_player_ids' => array("3cb95584-7313-4b27-a834-4b3bea5ba88b"),
            'data' => array("foo" => "bar"),
            'contents' => $content,
            'headings' => $Headings,
            'url' => "localhost:8000/cadastro"
        );
        
        $fields = json_encode($fields);
       
        
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, "https://onesignal.com/api/v1/notifications");
        curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json; charset=utf-8',
                                                   'Authorization: Basic NGEwMGZmMjItY2NkNy0xMWUzLTk5ZDUtMDAwYzI5NDBlNjJj'));
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
        curl_setopt($ch, CURLOPT_HEADER, FALSE);
        curl_setopt($ch, CURLOPT_POST, TRUE);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $fields);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);

        $response = curl_exec($ch);
        curl_close($ch);
        
        return $response;
    }
    
    $response = sendMessage();
    $return["allresponses"] = $response;
    $return = json_encode( $return);
    // funcao do push
   

    use App\Protocolo;
    use App\Usuario;
	$Protocolo = Protocolo::all();
    $protocolo = array();
    $ano = array();
    $tipo = array();
    $arquivado = array();
    $descricao = array();
    if($tipo_usuario == 0){
    	foreach($Protocolo as $row){
    		if ($row->email == $email){
                if($row->arquivado == "1"){
    			 $protocolo[] = $row->protocolo;
    			 $ano[] = $row->ano;
                    $tipo[] = $row->tipo;
                    $arquivado[] = $row->arquivado;
                    $descricao[] = $row->descricao;
                }
    		}
    	} 
    }
    $tamanho = count($protocolo);
?>

<!-- Pagina do Usuario -->
<?php
    //tipo de usuario = 0 para usuarios comuns
    if($tipo_usuario == 0){  
?>
<div class="row">
                    <!-- Column -->
                    <div class="col-lg-9 col-md-12">
                        <div class="card" style="left:150px; margin-top:20px;">
                            <div class="card-body" >
                                <div class="d-flex no-block">
                                    <h4 class="card-title">Protocolos arquivados</h4>
                                    <!-- div do select para selecionar a ordenação (qlq coisa)
                                    <div class="ml-auto">
                                        <select class="custom-select">
                                            <option selected="">Electronics</option>
                                            <option value="1">Kitchen</option>
                                            <option value="2">Crocory</option>
                                            <option value="3">Wooden</option>
                                        </select>
                                    </div>
                                	-->
                                </div>
                                <div class="table-responsive">
                                    <table class="table stylish-table">
                                        <thead>
                                            <tr>
                                                <th>Numero</th>
                                                <th>Ano</th>
                                                <th>Tipo</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                        	<?php
                                        	for ($i = 0; $i < $tamanho ; $i++){
                                            
                                            $ano_aux_numero = $ano[$i];
                                            if($tipo[$i] == "1"){ 
                                                $ano_aux = $ano[$i];
                                                $mensagem1 ="Ambiental";
                                            }
                                            else{
                                                $ano_aux = "----";
                                                $mensagem1 = "Comercial";
                                            }
                                        	echo "<tr>";
                                        		echo "<td>";
                                        			echo "<h6><a href=\"javascript:showprotocolos(".$protocolo[$i].",".$ano_aux_numero.");\" class=\"link\"> ".$protocolo[$i]."</a></h6><small class=\"text-muted\">".$descricao[$i]." </small>";
                                        		echo "</td>";
                                        		echo "<td>";
                                        			echo "<h5>".$ano_aux."</h5>";
                                        		echo "</td>";
                                                echo "<td>";
                                                    echo "<h5>".$mensagem1."</h5>";
                                                echo "</td>";
                                                echo "<td>";
                                                echo "<button type=\"button\" onclick=\"desarquivar_protocolos('".$protocolo[$i]."',".$ano_aux_numero.",'".$email."',".$tipo[$i].");\" class=\"btn btn-inverse waves-effect waves-light m-r-10\">Desarquivar</button> ";
                                                echo "</td>";
                                                echo "<td>";
                                                echo "<button type=\"button\" disabled onclick=\"showprotocolos(".$protocolo[$i].",".$ano_aux_numero.");\" class=\"btn btn-success waves-effect waves-light m-r-10\">Relembrar Processo</button> ";
                                                echo "</td>";

                                        	echo "</tr>";
                        
                                            }
                                        	?>
                                            <form id="protocolos" action="/desarquivar_protocolo" method="post">
                                <input type="hidden" name="protocolo" value="">
                                <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                                <input type="hidden"  name="ano" value="">
                                <input type="hidden"  name="email_arquivado" value="0">
                                <input type="hidden" id="channel" name="channel" value="<?php echo e($email); ?>">
                                <input type="hidden"  name="tipo_arquivado" value="0">
                            </form>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                </div>
</div>
</div>
</div>

<script>
    function showprotocolos(protocolo,ano){
        document.getElementsByName('protocolo')[0].value = protocolo;
        document.getElementsByName('ano')[0].value = ano;
        
        document.getElementById("protocolos").submit();
    }
</script>
<script>
    function desarquivar_protocolos(protocolo,ano,email_aux,tipo){
        
        document.getElementsByName('protocolo')[0].value = protocolo;
        document.getElementsByName('ano')[0].value = ano;
        document.getElementsByName('email_arquivado')[0].value = email_aux;
        document.getElementsByName('tipo_arquivado')[0].value = tipo;
        document.getElementById("protocolos").submit();
    }
</script>
<script>
    function desativarUsuario(email_aux,acao){
        document.getElementsByName('email_desativado')[0].value = email_aux;
        document.getElementsByName('acao')[0].value = acao;
        document.getElementById("desativar").submit();
    }
</script>


<script src="https://cdn.onesignal.com/sdks/OneSignalSDK.js" async=""></script>
<script>
  var OneSignal = window.OneSignal || [];
  OneSignal.push(function() {
    OneSignal.init({
      appId: "04d9a36d-4ec7-4b51-9ad2-7e4664417186",
      autoRegister: false,
      notifyButton: {
        enable: true, /* Required to use the Subscription Bell */
        size: 'medium', /* One of 'small', 'medium', or 'large' */
        theme: 'default', /* One of 'default' (red-white) or 'inverse" (white-red) */
        position: 'bottom-right', /* Either 'bottom-left' or 'bottom-right' */
        offset: {
            bottom: '0px',
            left: '0px', /* Only applied if bottom-left */
            right: '0px' /* Only applied if bottom-right */
        },
        prenotify: true, /* Show an icon with 1 unread message for first-time site visitors */
        showCredit: false, /* Hide the OneSignal logo */
        text: {
            'tip.state.unsubscribed': 'Se inscreva para receber notificações',
            'tip.state.subscribed': "Você esta inscrito para receber notificações",
            'tip.state.blocked': "notificações bloqueadas",
            'message.prenotify': 'Clique para receber notificações',
            'message.action.subscribed': "Obrigado por se inscrever!",
            'message.action.resubscribed': "Você esta inscrito para receber notificações",
            'message.action.unsubscribed': "Você não receberá notificações",
            'dialog.main.title': 'Inscreva-se',
            'dialog.main.button.subscribe': 'Aceitar',
            'dialog.main.button.unsubscribe': 'Cancelar',
            'dialog.blocked.title': 'Desbloquear notificações',
            'dialog.blocked.message': "Follow these instructions to allow notifications:"
        }
    },
    });
    OneSignal.getUserId(function(userId) {
        document.getElementsByName('channel')[0].value = userId;
    });
  });
</script> 

  
</body>
<!-- Chamando o footer.blade.php que contem as chamadas do js e o footer -->
<?php echo $__env->make('footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php 
} ?>
<!-- Fechando as divs e o body do header -->
