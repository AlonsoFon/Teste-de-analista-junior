<!DOCTYPE html>
<html lang="en">

<!-- Chamando o header.blade.php que contem as chamadas do css e o header -->

<?php echo $__env->make('header_login', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>


<div class="row">
    <div class="col-10">
        <div class="card card-body" style=" left:50px; margin-top: 80px;">
            <h3 class="box-title m-b-0">Cadastro de usuarios</h3>
            <p class="text-muted m-b-30 font-13"> Insira suas informa&ccedil;&otilde;es abaixo </p>
            
            <div class="row">
                <div class="col-sm-12 col-xs-12">
                    
                    <form class="floating-labels m-t-40"
class="floating-labels m-t-40">
                        <div class="form-group">
                            <label for="exampleInputEmail1">Nome</label>
                            <input type="text" class="form-control" id="nome" name="nome" value="<?php echo e(old('nome')); ?>" > 
                            <?php if(count($errors) > 0): ?>
                                <?php if($errors->has('nome')): ?> 
                                    <br>
                                    <div class = "alert alert-danger">
                                        <ul>
                                        <li><?php echo e($errors->first('nome')); ?></li>
                                        </ul>
                                    </div>
                                <?php endif; ?>
                             <?php endif; ?>
                            <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                        </div>
                        <div class="form-group">
                            <label for="exampleInputEmail1">Email</label>
                            <input type="email" class="form-control" id="email" name="email" value="<?php echo e(old('email')); ?>" >
                            <?php if(count($errors) > 0): ?>
                                <?php if($errors->has('email')): ?> 
                                    <br>
                                    <div class = "alert alert-danger">
                                        <ul>
                                        <li><?php echo e($errors->first('email')); ?></li>
                                        </ul>
                                    </div>
                                <?php endif; ?>
                             <?php endif; ?>
                        </div>
                        <div class="form-group">
                            <label for="exampleInputPassword1">Senha</label>
                            <input type="password" class="form-control" id="senha" name="senha" value="">

                            <div class="form-group" style="margin-top: 20px">
                            <label for="exampleInputPassword1">Confirmar senha</label>
                            <input type="password" class="form-control" id="senha_confirmation" name="senha_confirmation" >
                            </div>
                            <?php if(count($errors) > 0): ?>
                                <?php if($errors->has('senha')): ?> 
                                    <div class = "alert alert-danger">
                                        <ul>
                                        <li><?php echo e($errors->first('senha')); ?></li>
                                        </ul>
                                    </div>
                                <?php endif; ?>
                             <?php endif; ?>
                        </div>
                        <div class="form-group">
                            <label for="exampleInputEmail1">Telefone</label>
                            <input type="text" class="form-control" id="telefone" name="telefone" value="<?php echo e(old('telefone')); ?>" data-mask="(99) 99999-9999">
                             <?php if(count($errors) > 0): ?>
                                <?php if($errors->has('telefone')): ?> 
                                    <br>
                                    <div class = "alert alert-danger">
                                        <ul>
                                        <li><?php echo e($errors->first('telefone')); ?></li>
                                        </ul>
                                    </div>
                                <?php endif; ?>
                             <?php endif; ?>
                        </div>

                       
                        <div class="form-group">
                            <label for="exampleInputEmail1">Cpf</label>
                            <input type="text" class="form-control" id="cpf" name="cpf" <?php if (count($errors) > 0){ ?> value="" <?php } else{ ?> value="<?php echo e(old('cpf')); ?>" <?php } ?> data-mask="999.999.999-99" >
                             <?php if(count($errors) > 0): ?>
                                <?php if($errors->has('cpf')): ?> 
                                    <br>
                                    <div class = "alert alert-danger">
                                        <ul>
                                        <li><?php echo e($errors->first('cpf')); ?></li>
                                        </ul>
                                    </div>
                                <?php endif; ?>
                             <?php endif; ?>
                        </div>
                        <div class="form-group">
                            <label for="exampleInputEmail1">Profissao</label>
                                <div id="the-basics">
                                    <input class="typeahead form-control" type="text" placeholder="Profiss&atilde;o" id="profissao" name="profissao" value="<?php echo e(old('profissao')); ?>" >
                                </div>
                        </div>
                        
                         <!-- div endereco -->
                       
                        <div class="row">
                            <div class="col-sm-3 nopadding">
                                <div class="form-group">
                                    <input type="text" class="form-control" id="logradouro" name="logradouro" value="<?php echo e(old('logradouro')); ?>" placeholder="Logradouro">
                                </div>
                            </div>
                            <div class="col-sm-3 nopadding">
                                <div class="form-group">
                                    <input type="text" class="form-control" id="bairro" name="bairro" value="<?php echo e(old('bairro')); ?>" placeholder="Bairro">
                                </div>
                            </div>
                            <div class="col-sm-3 nopadding">
                                <div class="form-group">
                                    <input type="text" class="form-control" id="numero" name="numero" value="<?php echo e(old('numero')); ?>" placeholder="Numero">
                                </div>
                            </div>
                            <div class="col-sm-3 nopadding">
                                <div class="form-group">
                                    <input type="text" class="form-control" id="complemento" name="complemento" value="<?php echo e(old('complemento')); ?>" placeholder="Complemento">
                                </div>
                            </div>
                        </div>
                       <?php
                           $estado = "";
                           $estado = old('estado');
                       ?>
                        <div class="row">
                            <div class="col-sm-4 nopadding">
                                <div class="form-group">
                                    <input type="text" class="form-control" id="cidade" name="cidade" value="<?php echo e(old('cidade')); ?>" placeholder="cidade">
                                </div>
                            </div>
                            <div class="col-sm-3 nopadding" style="margin-top:10px">
                                <div class="form-group">
                                    <select  class="custom-select" name="estado">
                                    <option <?php if($estado == "Acre"){ ?> selected <?php } ?> value="Acre">Acre</option>
                                    <option <?php if($estado == "Alagoas"){ ?> selected <?php } ?> value="Alagoas">Alagoas</option>
                                    <option <?php if($estado == "Amapa"){ ?> selected <?php } ?> value="Amapa">Amap&aacute;</option>
                                    <option <?php if($estado == "Amazonas"){ ?> selected <?php } ?> value="Amazonas">Amazonas</option>
                                    <option <?php if($estado == "Bahia"){ ?> selected <?php } ?> value="Bahia">Bahia</option>
                                    <option <?php if($estado == "Ceara"){ ?> selected <?php } ?> value="Ceara">Cear&aacute;</option>
                                    <option <?php if($estado == "Distrito Federal"){ ?> selected <?php } ?> value="Distrito Federal">Distrito Federal</option>
                                    <option <?php if($estado == "Espirito Santo"){ ?> selected <?php } ?> value="Espirito Santo">Esp&iacute;rito Santo</option>
                                    <option <?php if($estado == "Goias"){ ?> selected <?php } ?> value="Goias">Goi&aacute;s</option>
                                    <option <?php if($estado == "Maranhao"){ ?> selected <?php } ?> value="Maranhao">Maranh&atilde;o</option>
                                    <option <?php if($estado == "Mato Grosso"){ ?> selected <?php } ?> value="Mato Grosso">Mato Grosso</option>
                                    <option <?php if($estado == "Mato Grosso do Sul"){ ?> selected <?php } ?> value="Mato Grosso do Sul">Mato Grosso do Sul</option>
                                    <option <?php if($estado == "Minas Gerais"){ ?> selected <?php } ?> value="Minas Gerais">Minas Gerais</option>
                                    <option <?php if($estado == "Para"){ ?> selected <?php } ?> value="Para">Par&aacute;</option>
                                    <option <?php if($estado == "Paraiba"){ ?> selected <?php } ?> value="Paraiba">Para&iacute;ba</option>
                                    <option <?php if($estado == "Parana"){ ?> selected <?php } ?> value="Parana">Paran&aacute;</option>
                                    <option <?php if($estado == "Pernambuco"){ ?> selected <?php } ?> value="Pernambuco">Pernambuco</option>
                                    <option <?php if($estado == "Piaui"){ ?> selected <?php } ?> value="Piaui">Piau&iacute;</option>
                                    <option <?php if($estado == "Rio de Janeiro"){ ?> selected <?php } ?> value="Rio de Janeiro">Rio de Janeiro</option>
                                    <option <?php if($estado == "Rio Grande do Norte"){ ?> selected <?php } ?> value="Rio Grande do Norte">Rio Grande do Norte</option>
                                    <option <?php if($estado == "Rio Grande do Sul"){ ?> selected <?php } ?> value="Rio Grande do Sul">Rio Grande do Sul</option>
                                    <option <?php if($estado == "Rondonia"){ ?> selected <?php } ?> value="Rondonia">Rond&ocirc;nia</option>
                                    <option <?php if($estado == "Roraima"){ ?> selected <?php } ?> value="Roraima">Roraima</option>
                                    <option <?php if($estado == "Santa Catarina"){ ?> selected <?php } ?> value="Santa Catarina">Santa Catarina</option>
                                    <option <?php if($estado == "Sao Paulo"){ ?> selected <?php } ?> value="Sao Paulo">S&atilde;o Paulo</option>
                                    <option <?php if($estado == "Sergipe"){ ?> selected <?php } ?> value="Sergipe">Sergipe</option>
                                    <option <?php if($estado == "Tocantins"){ ?> selected <?php } ?> value="Tocantins">Tocantins</option>

                                    </select>
                                </div>
                            </div>
                        </div>
                        
                        <!-- div do endereco -->
                        <!-- div dos protocolos -->
                        <div class="card">
                            <div class="card-body">
                                <h4 class="card-title">Protocolos</h4>
                                <div id="education_fields"></div>
                                <div class="row">
                                    <div class="col-sm-5 nopadding">
                                        <div class="form-group">
                                            <input type="text" class="form-control" id="protocolo" name="protocolo[]" value="" placeholder="numero do protocolo">
                                        </div>
                                    </div>
                                    <div class="col-sm-3 nopadding" style="margin-top:10px">
                                        <div class="form-group">
                                            <select  class="custom-select" name="ano[]">
                                            <option value="2005">2005</option>
                                            <option value="2006">2006</option>
                                            <option value="2007">2007</option>
                                            <option value="2008">2008</option>
                                            <option value="2009">2009</option>
                                            <option value="2010">2010</option>
                                            <option value="2011">2011</option>
                                            <option value="2012">2012</option>
                                            <option value="2013">2013</option>
                                            <option value="2014">2014</option>
                                            <option value="2015">2015</option>
                                            <option value="2016">2016</option>
                                            <option value="2017">2017</option>
                                            <option value="2018">2018</option>
                                        </select>
                                        </div>
                                    </div>
                                    <div class="col-sm-3" style="margin-top:20px">
                                       <span name="marcador_nome[]" >Ambiental</span>
                                       <input type="hidden" name="marcador_valor[]" value="1">

                                       <input type="checkbox" class="js-switch" onchange="desmarca('x')" name="marcador_checker[]" value="1" data-color="#26c6da" data-size="small" data-secondary-color="#f62d51">
                                    </div>
                                    <div class="col-sm-1 nopadding" style="margin-top:10px">
                                        <div class="form-group">
                                            <div class="input-group">
                                                <div class="input-group-append">
                                                    <button class="btn btn-success" type="button" onclick="education_fields();"><i class="fa fa-plus"></i></button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                    <div class="demo-radio-button">
                        <div>Notificar sobre o protocolo a cada: </div>
                                            <input name="groupi" value="5" type="radio" id="radio_1" checked />
                                            <label for="radio_1">5 dias</label>
                                            <input name="groupi" value="15" type="radio" id="radio_2" />
                                            <label for="radio_2">15 dias</label>
                            <input name="groupi" value="30" type="radio" id="radio_3" />
                                            <label for="radio_3">30 dias</label>
                                    </div>
                                </div>
                                </div>
                            </div>
                        </div>  
                        <!-- div dos protocolos -->
            <div class="form-group">
                <input type="checkbox" id="aplica" onclick="aceitou();" name="aplica" value="1" class="filled-in chk-col-red" />
                                <label for="aplica" style="margin-right:50px">Aceitar termos de uso</label>
                <a href="#"  onclick="window.open('http://www.prottocol.com.br/termos_de_uso', 'Titulo da Janela', 'STATUS=NO, TOOLBAR=NO, LOCATION=NO, DIRECTORIES=NO, RESISABLE=NO, SCROLLBARS=YES, TOP=10, LEFT=10, WIDTH=770, HEIGHT=400');"> <br>Ler termos de uso do site</a>
            </div>
        <br>
            <div class="form-group">
                            <button type="submit" style="display:none" id="cadastrar" formmethod="post" class="btn btn-success waves-effect waves-light m-r-10">Cadastrar</button>
                            <button type="button" onclick="voltar();" class="btn btn-inverse waves-effect waves-light">Voltar</button>
                            <a href="/login" style="display:none" id="ex">Triggerable link</a>
                        </div>
                    </form>
                </div>
            </div>

            



        </div>
    </div>
</div>


<script>
    function voltar(){
        $('#ex').click();
        location.href=$('#ex').attr('href');
    }
</script>

<script>
    function aceitou(){
        if (!document.getElementById('aplica').checked) document.getElementById('cadastrar').style.display = 'none';
        else document.getElementById('cadastrar').style.display = 'inline';
    }
</script>



<script>
    function desmarca(posicao){
        var marcador_checker = document.getElementsByName('marcador_checker[]');
        var ano = document.getElementsByName('ano[]');
        var marcador_nome = document.getElementsByName('marcador_nome[]');
        var marcador_valor = document.getElementsByName('marcador_valor[]');
        if(posicao == 'x') posicao = marcador_checker.length-1;
        if (marcador_checker[posicao].checked){
            //colocar disable do ano disabled
            ano[posicao].disabled = "TRUE";
            marcador_nome[posicao].innerHTML="Comercial";
            marcador_valor[posicao].value = "2";
        }else{
           ano[posicao].removeAttribute('disabled');
           marcador_nome[posicao].innerHTML="Ambiental"; 
           marcador_valor[posicao].value = "1";
        }
        
    }
</script>

<!-- chamada do Javascript da div dinamida dos protocolos -->
<script src="/public/assets/plugins/dff/dff.js" type="text/javascript"></script>



<!-- Fechando as divs e o body do header -- >
</div>    
</div>
</div>


<!-- ============================================================== -->
    <!-- End Wrapper -->
    <!-- ============================================================== -->
    <!-- ============================================================== -->
    <!-- All Jquery -->
    <!-- ============================================================== -->
    <script src="/public/assets/plugins/jquery/jquery.min.js"></script>
    <!-- Bootstrap tether Core JavaScript -->
    
    
    
    <!-- ============================================================== -->
    <!-- This page plugins -->
    <!-- ============================================================== -->
    <script src="/public/assets/plugins/switchery/dist/switchery.min.js"></script>
    
    <script>
    jQuery(document).ready(function() {
        // Switchery
        var marcador_checker = document.getElementsByName('marcador_checker[]');
        $('.js-switch').each(function() {
            new Switchery($(this)[0], $(this).data());
        });
        marcador_checker[0].value = "chamado";
    });
    </script>
   
</body>

<!-- Chamando o footer.blade.php que contem as chamadas do js e o footer -->
<?php echo $__env->make('footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<script src="/public/assets/plugins/bootstrap-select/bootstrap-select.min.js" type="text/javascript"></script>
<script src="/public/js/mask.js"></script>
<script src="/public/assets/plugins/typeahead.js-master/dist/typeahead.bundle.min.js"></script>
<script src="/public/assets/plugins/typeahead.js-master/dist/typeahead-init.js"></script>