<!DOCTYPE html>
<html lang="en">


<!-- Chamando o header.blade.php que contem as chamadas do css e o header -->
<?php echo $__env->make('header_index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php
	use App\Protocolo;
	use App\Movimentacao;
	// protocolo de sp
	/*
	$url_aux ="http://licenciamento.cetesb.sp.gov.br/cetesb/processo_resultado.asp";
	$ch = curl_init();
	$timeout = 0;
	curl_setopt($ch, CURLOPT_URL, $url_aux);
	// ENABLE HTTP POST
	curl_setopt ($ch, CURLOPT_POST, 1);

	// SET POST PARAMETERS : FORM VALUES FOR EACH FIELD
	curl_setopt ($ch, CURLOPT_POSTFIELDS, 'sd=21007880');
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, $timeout);
	$conteudo = curl_exec ($ch);
	curl_close($ch);
	$retirar = "<input type=submit name=\"Submit\" value=\"Consulte ...\" class=\"estilo\">";
	$validar = strpos($conteudo, $retirar);
	$validar = $validar + 75;
	$conteudo = substr($conteudo, $validar);
	// corrigindo os caracteres ?? 
	$encoding = mb_detect_encoding($conteudo, 'utf-8, iso-8859-1, ascii', true);
	if (strcasecmp($encoding, 'UTF-8') !== 0) {
		$conteudo = iconv($encoding, 'utf-8', $conteudo);
	}
	// retirando o (ï»¿)BOM gerado ao mudar o encoding acima 
	$retirar = "ï»¿";
	$conteudo = str_replace($retirar, "", $conteudo);
	echo $conteudo;
	*/
	
	if($ano == 0){
		$url_aux ="http://portalservicos.jucemat.mt.gov.br/Portal/pages/consultaProcesso.jsf";
	}else {
		$url_aux ="http://www.protocolo.sad.mt.gov.br/consulta/ep.php?p_anoProcesso=".$ano."&p_numeroProcesso=".$protocolo;
	}
	// apagar se nao der certo
	
	
	// pegando o conteudo da pagina $url_aux e colocando em $conteudo
	$ch = curl_init();
	$timeout = 0;
	curl_setopt($ch, CURLOPT_URL, $url_aux);
	// ENABLE HTTP POST
	curl_setopt ($ch, CURLOPT_POST, 1);

	// SET POST PARAMETERS : FORM VALUES FOR EACH FIELD
	curl_setopt ($ch, CURLOPT_POSTFIELDS, 'protocolo=180397389');
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, $timeout);
	$conteudo = curl_exec ($ch);
	curl_close($ch);
	//iframe para fazer o site
	//echo "<iframe src=\"http://portalservicos.jucemat.mt.gov.br/Portal/pages/consultaProcesso.jsf\"></iframe>\"";

	// verificando se a pagina retornada nao é valida
	$validar = strpos($conteudo, 'continuar');
	if ($validar == ""){
		if($ano == 0){
			// arrumar o site do protocolo comercial
			// arrumando o caminho dos arquivos
			$retirar = "src=\"/Portal";
			$substituir = "src=\"http://portalservicos.jucemat.mt.gov.br/Portal";
			$conteudo = str_replace($retirar, $substituir, $conteudo);
			$retirar = "href=\"/Portal";
			$substituir = "href=\"http://portalservicos.jucemat.mt.gov.br/Portal";
			$conteudo = str_replace($retirar, $substituir, $conteudo);
			
		
			
			// teste 1 arrumando o link do action do form
			$retirar = "action=\"/Portal/pages/";
			$substituir = "";
			$conteudo = str_replace($retirar, $substituir, $conteudo);
			//teste 2
			$retirar = "method=\"post\"";
			$substituir = "method=\"post\" action=\"http://portalservicos.jucemat.mt.gov.br/Portal/pages/consultaProcesso.jsf";
			$conteudo = str_replace($retirar, $substituir, $conteudo);
			

			


		}else{
			// arrumando site protocolo ambiental
			// fazendo a barra azul top sumir
			$retirar = "height=\"76\"";
			$substituir = "height=\"76\" style=\"display:none;\"";
			$conteudo = str_replace($retirar, $substituir, $conteudo);
			// corrigindo os caracteres ?? 
			$encoding = mb_detect_encoding($conteudo, 'utf-8, iso-8859-1, ascii', true);
			if (strcasecmp($encoding, 'UTF-8') !== 0) {
			   $conteudo = iconv($encoding, 'utf-8', $conteudo);
			}
			// retirando o (ï»¿)BOM gerado ao mudar o encoding acima 
			$retirar = "ï»¿";
			$conteudo = str_replace($retirar, "", $conteudo);
			// retirando o botao nova consulta 
			$retirar = "value=\"Nova Consulta\"";
			$substituir = "value=\"Nova Consulta\" style=\"display:none;\"";
			$conteudo = str_replace($retirar, $substituir, $conteudo);
			// alinhando o conteudo
			$retirar = "p align=\"center\"";
			$substituir = "p align=\"center\" style=\"margin-top:20px;\"";
			$conteudo = str_replace($retirar, $substituir, $conteudo);
			// procurando o assunto
			$findme = "Resumo do Assunto";
			$pos = strpos($conteudo, $findme);
			$pos = $pos + 115;
			$findme = "Parte Interessada";
			$pos2 = strpos($conteudo, $findme);
			$pos2 = $pos2 - 119;
			$pos3 = $pos2 - $pos;
			$Protocolo = Protocolo::all();
			foreach ($Protocolo as $row) {
				if( ($row->email == $email) && ($row->ano == $ano) && ($row->protocolo == $protocolo) ){
					if($row->descricao == "---") $descricao_existe = "0";
					else  $descricao_existe = "1";
				}
			}
			if($descricao_existe == "0"){
				$descricao = substr($conteudo,$pos,$pos3);
				$affectedRows = Protocolo::where('email', '=', $email)->where('protocolo', '=', $protocolo)->where('ano', '=', $ano)->where('tipo', '=', $tipo_arquivo)->update(array('descricao' => $descricao));
			}
		}
		//primeira parte de informacoes comuns para todas as movimentacoes 
		// procurando o assunto
		$findme = "Assunto";
		$pos = strpos($conteudo, $findme);
		$pos = $pos + 105;
		$findme = "Resumo do Assunto";
		$pos2 = strpos($conteudo, $findme);
		$pos2 = $pos2 - 107;
		$pos3 = $pos2 - $pos;
		$Assunto = substr($conteudo,$pos,$pos3);

		// procurando o resumo do assunto
		$findme = "Resumo do Assunto";
		$pos = strpos($conteudo, $findme);
		$pos = $pos + 115;
		$findme = "Parte Interessada";
		$pos2 = strpos($conteudo, $findme);
		$pos2 = $pos2 - 119;
		$pos3 = $pos2 - $pos;
		$Res_assunto = substr($conteudo,$pos,$pos3);

		// procurando a parte interessada
		$findme = "Parte Interessada";
		$pos = strpos($conteudo, $findme);
		$pos = $pos + 139;
		$findme = "Unidade Atual";
		$pos2 = strpos($conteudo, $findme);
		$pos2 = $pos2 - 121;
		$pos3 = $pos2 - $pos;
		$Parte_interessada = substr($conteudo,$pos,$pos3);

		// procurando a Unidade atual
		$findme = "Unidade Atual";
		$pos = strpos($conteudo, $findme);
		$pos = $pos + 85;
		$findme = "</table>";
		$pos2 = strpos($conteudo, $findme);
		$pos2 = $pos2 - 1895;
		$pos3 = $pos2 ;
		$Unidade_atual = substr($conteudo,$pos,$pos3);

		// procurando a table de movimentacoes
		$findme = "<table width=\"100%\" border=\"0\" cellspacing=\"2\" cellpadding=\"2\">";
		$pos = strpos($conteudo, $findme);
		$pos = $pos + 115;
		$findme = "</table>";
		$pos2 = strripos($conteudo, $findme);
		$descricao = substr($conteudo,$pos,$pos2);
		$pos2 = strlen($descricao);
		$pos = strpos($descricao, "<hr>");
		$descricao = substr($descricao,$pos,$pos2);
		//trabalhando aqui
		$contador_while = substr_count($descricao, '<hr>');
		$numero_ocor = 1;
		$info_banco = explode("<hr>", $descricao);
		$tamanho_info_banco = count($info_banco);
		//ate aqui
		//pegando as informacoes de origem (colocar um while)
		
		echo $conteudo;
		for($i=1;$i<$tamanho_info_banco;$i++){
			$pos2 = strpos($info_banco[$i], "<div align=\"center\">");
			$info_origem = substr($info_banco[$i],0,$pos2);
			// pegando o orgao e setor de origem 
			$pos2 = strpos($info_origem, "<span class=\"textoazul2\">");
			$primeira_parte_origem = substr($info_origem,0,$pos2);
			$primeira_parte_origem = str_replace("<hr>", "", $primeira_parte_origem);
			$pos2 = strlen($primeira_parte_origem);
			// separando o orgao do setor de origem
			$primeira_parte_origem = substr($primeira_parte_origem,89,$pos2);
			$primeira_parte_origem = explode("</td>", $primeira_parte_origem);
			$Movimentacao = new Movimentacao();

			if(isset($primeira_parte_origem[0])) $Movimentacao->orgao_origem = $primeira_parte_origem[0];
			else $Movimentacao->orgao_origem = "";
			if($Movimentacao->orgao_origem != ""){
				//manipulando o setor para tirar os lixos
				if(isset($primeira_parte_origem[1])) {
					$setor_origem = str_replace("<td width=\"89\" align=\"center\" class=\"textopreto\">", "", $primeira_parte_origem[1]);
					$pos2 = strlen($setor_origem);
					$pos2 = $pos2 -7;
					$setor_origem = substr($setor_origem,4,$pos2);
					$Movimentacao->setor_origem = $setor_origem;
				}else{
					$Movimentacao->setor_origem = "";
				}
				
				// pegando a data e hora de origem
				$pos2 = strpos($info_origem, "&nbsp;");
				$pos = strpos($info_origem, "<span class=\"textoazul2\">"); 
				$pos = $pos +25;
				$segunda_parte_origem = substr($info_origem,$pos,$pos2);
				$segunda_parte_origem = str_replace("</span>", "", $segunda_parte_origem);
				// separando a data da hora de origem
				
				$segunda_parte_origem = explode("</td>", $segunda_parte_origem);
				if(isset($segunda_parte_origem[0])) $Movimentacao->data_origem = $segunda_parte_origem[0];
				else $Movimentacao->data_origem = "";
				if(isset($segunda_parte_origem[1])){
					$pos2 = strlen($segunda_parte_origem[1]);
					$pos2 = $pos2 -1;
					$hora_origem = substr($segunda_parte_origem[1],71,$pos2);
					$Movimentacao->hora_origem = $hora_origem;
				}else{
					$Movimentacao->hora_origem = "";
				}
				//pegando a acao
				$pos2 = stripos($info_banco[$i], "</div>");
				$pos = strpos($info_banco[$i], "<div align=\"center\">");
				$pos3 = strpos($info_banco[$i], "<font face=\"Verdana, Arial, Helvetica, sans-serif\" size=\"1\" color=\"#994444\">");
				$acao_origem = substr($info_banco[$i],$pos,180);
				$destino = substr($info_banco[$i],$pos3,$pos2);
				$acao_origem = str_replace("<font face=\"Verdana, Arial, Helvetica, sans-serif\" size=\"1\" color=\"#994444\">", "", $acao_origem);
				$pos2 = strlen($acao_origem);
				$pos2 = $pos2 - 96;
				$acao_origem = substr($acao_origem,30,$pos2);
				$Movimentacao->acao = $acao_origem;

				$destino = str_replace("<font face=\"Verdana, Arial, Helvetica, sans-serif\" size=\"1\" color=\"#994444\">", "", $destino);
				$destino = substr($destino,50);
				$destino = explode("</td>", $destino);
				echo $destino[0];
				echo "<br>";
				if(isset($destino[0])) $orgao_destino = str_replace("<td width=\"99\" class=\"textoazul\" align=\"center\">", "",$destino[0]);
				else $orgao_destino = "";
				$orgao_destino = str_replace(" ", "", $orgao_destino);
				$orgao_destino = substr($orgao_destino,1);
				if(isset($destino[1])) $setor_destino = str_replace("<td width=\"83\" class=\"textoazul2\" align=\"center\"><span class=\"textopreto\">", "", $destino[1]);
				else $setor_destino = "";
				$pos_setor_destino = strlen($setor_destino);
				$pos_setor_destino = $pos_setor_destino - 16;
				$setor_destino = substr($setor_destino,5,$pos_setor_destino);
				if(isset($destino[2])) $data_destino = str_replace("<td width=\"89\" align=\"center\"  class=\"textopreto\"><span class=\"textoazul2\">", "", $destino[2]);
				else $data_destino = "";
				$pos_data_destino = strlen($data_destino);
				$pos_data_destino = $pos_data_destino - 16;
				$data_destino = substr($data_destino,5,$pos_data_destino);
				if(isset($destino[3])) $hora_destino = str_replace("<td width=\"89\" align=\"center\"  class=\"textopreto\"><span class=\"textoazul2\">", "", $destino[3]);
				else $hora_destino = "";
				$pos_hora_destino = strlen($hora_destino);
				$pos_hora_destino = $pos_hora_destino - 15;
				$hora_destino = substr($hora_destino,5,$pos_hora_destino);
				
				// fazendo o complemento
				$complemento_pos = strpos($info_banco[$i],"Encaminhamento:");
				$complemento_pos_final = $complemento_pos +500;
				$complemento = substr($info_banco[$i],$complemento_pos,$complemento_pos_final);
				$complemento_pos = strpos($complemento,"</table>");
				$complemento = substr($complemento,0,$complemento_pos);
				$complemento = explode("<tr>", $complemento);
				$tamanho_complemento = count($complemento);
				$Encaminhamento = "";
				if($tamanho_complemento > 1){
					for($j=1;$j<$tamanho_complemento;$j++){
				
						if (isset($complemento[$j]) )$Encaminhamento = $Encaminhamento."|||".$complemento[$j];
					}
				}
				
				$Encaminhamento = str_replace("<font face=\"Arial, sans-serif\" size=\"1\" color=\"#001155\">", "", $Encaminhamento);
				$Encaminhamento = str_replace("<td bgcolor=\"#FFFFFF\">","",$Encaminhamento);
				$Encaminhamento = str_replace("</font>","",$Encaminhamento);
				$Encaminhamento = str_replace("</td>","",$Encaminhamento);
				$Encaminhamento = str_replace("</tr>","",$Encaminhamento);
				$Movimentacao->orgao_destino = $orgao_destino;
				$Movimentacao->setor_destino = $setor_destino;
				$Movimentacao->data_destino = $data_destino;
				$Movimentacao->hora_destino = $hora_destino;
				$Movimentacao->protocolo = $protocolo;
				$Movimentacao->ano = $ano; 
				$Movimentacao->assunto = $Assunto;
				$Movimentacao->resumo_assunto = $Res_assunto;
				$Movimentacao->parte_interessada = $Parte_interessada;
				$Movimentacao->unidade_atual = $Unidade_atual;
				$Movimentacao->encaminhamento = $Encaminhamento;
				$Movimentacao_aux = Movimentacao::all();
				$tem = 0;
				foreach ($Movimentacao_aux as $row) {
					if( ($Movimentacao->orgao_origem == $row->orgao_origem) && ($Movimentacao->setor_origem == $row->setor_origem) && ($Movimentacao->data_origem == $row->data_origem) && ($Movimentacao->hora_origem == $row->hora_origem) && ($Movimentacao->acao == $row->acao) && ($Movimentacao->orgao_destino == $row->orgao_destino) && ($Movimentacao->setor_destino == $row->setor_destino) && ($Movimentacao->data_destino == $row->data_destino) && ($Movimentacao->hora_destino == $row->hora_destino) && ($row->protocolo == $protocolo) &&($row->ano == $ano) &&($row->assunto == $Assunto) &&($row->resumo_assunto == $Res_assunto) &&($row->parte_interessada == $Parte_interessada) &&($row->unidade_atual == $Unidade_atual) &&($row->encaminhamento == $Encaminhamento) ) $tem = 1;
				}
				
				if($tem == 0)$Movimentacao->save();
			}
		}
		
		
	}
	else{
		// se o protocolo tiver a palavra continuar significa que eh ambiental e deu erro entao retorna para o index
		echo "<script>function voltar1(){location.href= \"/error_index\";}voltar1();</script>";
		// fazer ao retornar para o index, exibir uma tela de erro;
	}
	
	
	
?>
<div class="form-group" align ="Center">
 	<button type="button" id="botaovoltar" style="width:150px;" onclick="voltar();" class="btn btn-inverse waves-effect waves-light">Voltar</button>
      	<a href="/index" style="display:none" id="ex">Triggerable link</a>
</div>

<script>
    function voltar(){
        $('#ex').click();
        location.href=$('#ex').attr('href');
    }
</script>


<!-- Fechando as divs e o body do header -->
</div>
</div>
</div>

</body>
<!-- Chamando o footer.blade.php que contem as chamadas do js e o footer -->
<?php echo $__env->make('footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>