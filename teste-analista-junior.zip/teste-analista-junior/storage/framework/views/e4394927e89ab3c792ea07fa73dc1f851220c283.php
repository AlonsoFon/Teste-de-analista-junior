
<?php echo $__env->make('header_index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>


<div class="row">
    <div class="col-10">
        <div class="card card-body" style="margin-top: 20px;">
            <h3 class="box-title m-b-0">Alterar senha</h3>
            <p class="text-muted m-b-30 font-13"> Insira suas informações abaixo </p>
            
            <div class="row">
                <div class="col-sm-12 col-xs-12">
                	
                    <form class="floating-labels m-t-40" class="floating-labels m-t-40">
                        
                        <div class="form-group">
                            <label for="exampleInputPassword1">Senha atual</label>
                            <input type="password" class="form-control" id="senha_atual" name="senha_atual">
                            <?php if(session('alert')): ?>
                                <div class="alert alert-danger">
                                    <?php echo e(session('alert')); ?>

                                </div>
                            <?php endif; ?>
                             <?php if(count($errors) > 0): ?>
                                <?php if($errors->has('senha')): ?> 
                                    <div class = "alert alert-danger">
                                        <ul>
                                        <li><?php echo e($errors->first('senha')); ?></li>
                                        </ul>
                                    </div>
                                <?php endif; ?>
                             <?php endif; ?>
                        </div>

                        <div class="form-group">

                            <label for="exampleInputPassword1">Nova senha</label>
                            <input type="password" class="form-control" id="senha" name="senha">
                            <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                            <div class="form-group" style="margin-top: 20px">
                            <label for="exampleInputPassword1">Confirmar nova senha</label>
                            <input type="password" class="form-control" id="senha_confirmation" name="senha_confirmation" >
                        	</div>
                            <?php if(count($errors) > 0): ?>
                            	<?php if($errors->has('senha')): ?> 
        							<div class = "alert alert-danger">
            							<ul>
    									<li><?php echo e($errors->first('senha')); ?></li>
										</ul>
        							</div>
       						 	<?php endif; ?>
       						 <?php endif; ?>
                        </div>
                        
                        <div class="form-group">
                        <button type="submit" formmethod="post" class="btn btn-success waves-effect waves-light m-r-10">Alterar</button>
                        <button type="button" onclick="voltar();" class="btn btn-inverse waves-effect waves-light">Voltar</button>
                        <a href="/index" style="display:none" id="ex">Triggerable link</a>
                    	</div>
                    </form>
                </div>
            </div>

            



        </div>
    </div>
</div>


<script>
	function voltar(){
		$('#ex').click();
		location.href=$('#ex').attr('href');
	}
</script>








<!-- Fechando as divs e o body do header -- >
</div>    
</div>
</div>


   
   
</body>

<!-- Chamando o footer.blade.php que contem as chamadas do js e o footer -->
<?php echo $__env->make('footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
s