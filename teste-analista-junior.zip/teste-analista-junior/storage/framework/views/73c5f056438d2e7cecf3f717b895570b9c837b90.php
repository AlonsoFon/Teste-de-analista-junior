<!DOCTYPE html>
<html lang="en">

<!-- Chamando o header.blade.php que contem as chamadas do css e o header -->

<?php echo $__env->make('header_index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>


<div class="row">
    <div class="col-10">
        <div class="card card-body" style=" left:115px; margin-top: 20px;">
            <h3 class="box-title m-b-0">Alterar senha</h3>
            <p class="text-muted m-b-30 font-13"> Insira suas informações abaixo </p>
            
            <div class="row">
                <div class="col-sm-12 col-xs-12">
                	
                    <form class="floating-labels m-t-40"
class="floating-labels m-t-40">
                        
                        <div class="form-group">
                            <label for="exampleInputPassword1">Senha atual</label>
                            <input type="password" class="form-control" id="senha_atual" name="senha_atual">
                            <?php if(session('alert')): ?>
                                <div class="alert alert-danger">
                                    <?php echo e(session('alert')); ?>

                                </div>
                            <?php endif; ?>
                             <?php if(count($errors) > 0): ?>
                                <?php if($errors->has('senha')): ?> 
                                    <div class = "alert alert-danger">
                                        <ul>
                                        <li><?php echo e($errors->first('senha')); ?></li>
                                        </ul>
                                    </div>
                                <?php endif; ?>
                             <?php endif; ?>
                        </div>

                        <div class="form-group">

                            <label for="exampleInputPassword1">Nova senha</label>
                            <input type="password" class="form-control" id="senha" name="senha">
                            <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                            <div class="form-group" style="margin-top: 20px">
                            <label for="exampleInputPassword1">Confirmar nova senha</label>
                            <input type="password" class="form-control" id="senha_confirmation" name="senha_confirmation" >
                        	</div>
                            <?php if(count($errors) > 0): ?>
                            	<?php if($errors->has('senha')): ?> 
        							<div class = "alert alert-danger">
            							<ul>
    									<li><?php echo e($errors->first('senha')); ?></li>
										</ul>
        							</div>
       						 	<?php endif; ?>
       						 <?php endif; ?>
                        </div>
                        
                        <div class="form-group">
                        <button type="submit" formmethod="post" class="btn btn-success waves-effect waves-light m-r-10">Alterar</button>
                        <button type="button" onclick="voltar();" class="btn btn-inverse waves-effect waves-light">Voltar</button>
                        <a href="/index" style="display:none" id="ex">Triggerable link</a>
                    	</div>
                    </form>
                </div>
            </div>

            



        </div>
    </div>
</div>


<script>
	function voltar(){
		$('#ex').click();
		location.href=$('#ex').attr('href');
	}
</script>



<script>
    function desmarca(posicao){
        var marcador_checker = document.getElementsByName('marcador_checker[]');
        var ano = document.getElementsByName('ano[]');
        var marcador_nome = document.getElementsByName('marcador_nome[]');
        var marcador_valor = document.getElementsByName('marcador_valor[]');
        if(posicao == 'x') posicao = marcador_checker.length-1;
        if (marcador_checker[posicao].checked){
            //colocar disable do ano disabled
            ano[posicao].disabled = "TRUE";
            marcador_nome[posicao].innerHTML="Comercial";
            marcador_valor[posicao].value = "2";
        }else{
           ano[posicao].removeAttribute('disabled');
           marcador_nome[posicao].innerHTML="Ambiental"; 
           marcador_valor[posicao].value = "1";
        }
        
    }
</script>

<!-- chamada do Javascript da div dinamida dos protocolos -->
<script src="../assets/plugins/dff/dff.js" type="text/javascript"></script>



<!-- Fechando as divs e o body do header -- >
</div>    
</div>
</div>


<!-- ============================================================== -->
    <!-- End Wrapper -->
    <!-- ============================================================== -->
    <!-- ============================================================== -->
    <!-- All Jquery -->
    <!-- ============================================================== -->
    <script src="../assets/plugins/jquery/jquery.min.js"></script>
    <!-- Bootstrap tether Core JavaScript -->
    
    
    
    <!-- ============================================================== -->
    <!-- This page plugins -->
    <!-- ============================================================== -->
    <script src="../assets/plugins/switchery/dist/switchery.min.js"></script>
    
    <script>
    jQuery(document).ready(function() {
        // Switchery
        var marcador_checker = document.getElementsByName('marcador_checker[]');
        $('.js-switch').each(function() {
            new Switchery($(this)[0], $(this).data());
        });
        marcador_checker[0].value = "chamado";
    });
    </script>
   
</body>

<!-- Chamando o footer.blade.php que contem as chamadas do js e o footer -->
<?php echo $__env->make('footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<script src="../assets/plugins/bootstrap-select/bootstrap-select.min.js" type="text/javascript"></script>
<script src="js/mask.js"></script>
<script src="../assets/plugins/typeahead.js-master/dist/typeahead.bundle.min.js"></script>
<script src="../assets/plugins/typeahead.js-master/dist/typeahead-init.js"></script>