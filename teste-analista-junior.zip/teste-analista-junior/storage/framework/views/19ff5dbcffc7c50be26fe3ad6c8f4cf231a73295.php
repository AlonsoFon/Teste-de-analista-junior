<!DOCTYPE html>
<html lang="en">

<!-- Chamando o header.blade.php que contem as chamadas do css e o header -->

<?php echo $__env->make('header_index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php 
    use App\Usuario;
    $Usuario = Usuario::all();
    
    foreach($Usuario as $row){
        if($email == $row->email){
            $nome_alt = $row->nome;
            $telefone_alt = $row->telefone;
            $endereco_alt = $row->endereco;
            $cpf_alt = $row->cpf;
            $profissao_alt = $row->profissao;
        }
    }
 ?>

<div class="row">
    <div class="col-10">
        <div class="card card-body" style=" left:115px; margin-top: 20px;">
            <h3 class="box-title m-b-0">Editar perfil</h3>
            <p class="text-muted m-b-30 font-13"> Insira suas informações abaixo </p>
            
            <div class="row">
                <div class="col-sm-12 col-xs-12">
                	
                    <form class="floating-labels m-t-40"
class="floating-labels m-t-40">
                        <div class="form-group">
                            <label for="exampleInputEmail1">Nome</label>
                            <input type="text" class="form-control" id="nome" name="nome" value="<?php echo e($nome_alt); ?>" > 
                            <?php if(count($errors) > 0): ?>
                            	<?php if($errors->has('nome')): ?> 
                                    <br>
        							<div class = "alert alert-danger">
            							<ul>
    									<li><?php echo e($errors->first('nome')); ?></li>
										</ul>
        							</div>
       						 	<?php endif; ?>
       						 <?php endif; ?>
                            <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                        </div>
                        
                        
                        <div class="form-group">
                            <label for="exampleInputEmail1">Telefone</label>
                            <input type="text" class="form-control" id="telefone" name="telefone" data-mask="(99) 99999-9999" value="<?php echo e($telefone_alt); ?>">
                             <?php if(count($errors) > 0): ?>
                            	<?php if($errors->has('telefone')): ?> 
                                    <br>
        							<div class = "alert alert-danger">
            							<ul>
    									<li><?php echo e($errors->first('telefone')); ?></li>
										</ul>
        							</div>
       						 	<?php endif; ?>
       						 <?php endif; ?>
                        </div>
                        <div class="form-group">
                            <label for="exampleInputEmail1">Endereço</label>
                            <input type="text" class="form-control" id="endereco" name="endereco" value="<?php echo e($endereco_alt); ?>" >
                        </div>
                        <div class="form-group">
                            <label for="exampleInputEmail1">Cpf</label>
                            <input type="text" class="form-control" id="cpf" name="cpf" data-mask="999.999.999-99" value="<?php echo e($cpf_alt); ?>" >
                             <?php if(count($errors) > 0): ?>
                            	<?php if($errors->has('cpf')): ?> 
                                    <br>
        							<div class = "alert alert-danger">
            							<ul>
    									<li><?php echo e($errors->first('cpf')); ?></li>
										</ul>
        							</div>
       						 	<?php endif; ?>
       						 <?php endif; ?>
                        </div>
                        <div class="form-group">
                            <label for="exampleInputEmail1">Profissão</label>
                                <div id="the-basics">
                                    <input class="typeahead form-control" type="text" placeholder="Profissão" id="profissao" name="profissao" value="<?php echo e($profissao_alt); ?>" >
                                </div>
                        </div>
                        
                        <div class="form-group">
                            <button type="submit" formmethod="post" class="btn btn-success waves-effect waves-light m-r-10">Editar</button>
                            <button type="button" onclick="voltar();" class="btn btn-inverse waves-effect waves-light">Voltar</button>
                            <a href="/index" style="display:none" id="ex">Triggerable link</a>
                    	</div>
                    </form>
                </div>
            </div>

            



        </div>
    </div>
</div>


<script>
	function voltar(){
		$('#ex').click();
		location.href=$('#ex').attr('href');
	}
</script>




<!-- chamada do Javascript da div dinamida dos protocolos -->
<script src="../assets/plugins/dff/dff.js" type="text/javascript"></script>



<!-- Fechando as divs e o body do header -- >
</div>    
</div>
</div>


<!-- ============================================================== -->
    <!-- End Wrapper -->
    <!-- ============================================================== -->
    <!-- ============================================================== -->
    <!-- All Jquery -->
    <!-- ============================================================== -->
    <script src="../assets/plugins/jquery/jquery.min.js"></script>
    <!-- Bootstrap tether Core JavaScript -->
    
    
    
    <!-- ============================================================== -->
    <!-- This page plugins -->
    <!-- ============================================================== -->
    <script src="../assets/plugins/switchery/dist/switchery.min.js"></script>
    
    
   
</body>

<!-- Chamando o footer.blade.php que contem as chamadas do js e o footer -->
<?php echo $__env->make('footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<script src="../assets/plugins/bootstrap-select/bootstrap-select.min.js" type="text/javascript"></script>
<script src="js/mask.js"></script>
<script src="../assets/plugins/typeahead.js-master/dist/typeahead.bundle.min.js"></script>
<script src="../assets/plugins/typeahead.js-master/dist/typeahead-init.js"></script>