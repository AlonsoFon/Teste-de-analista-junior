<!DOCTYPE html>
<html lang="en">

<!-- Chamando o header.blade.php que contem as chamadas do css e o header -->

<?php echo $__env->make('header_index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>



<div class="row">
    <div class="col-10">
        <div class="card card-body" style=" left:115px; margin-top: 20px;">
            <h3 class="box-title m-b-0">Adicionar protocolos</h3>
            <p class="text-muted m-b-30 font-13"> Insira suas informações abaixo </p>
            
            <div class="row">
                <div class="col-sm-12 col-xs-12">
                	
                    <form class="floating-labels m-t-40"
class="floating-labels m-t-40" action="/adiciona_protocolo" method="post">
                        <!-- div dos protocolos -->
                        <div class="card">
                            <div class="card-body">
                                <h4 class="card-title">Protocolo</h4>
                                <div id="education_fields"></div>
                                <div class="row">
                                    <div class="col-sm-5 nopadding">
                                        <div class="form-group">
                                            <input type="text" class="form-control" id="protocolo" name="protocolo[]" value="" placeholder="numero do protocolo">
                                            <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                                        </div>
                                    </div>
                                    <div class="col-sm-3 nopadding" style="margin-top:10px">
                                        <div class="form-group">
                                            <select class="custom-select" name="ano[]">
                                            <option value="2005">2005</option>
                                            <option value="2006">2006</option>
                                            <option value="2007">2007</option>
                                            <option value="2008">2008</option>
                                            <option value="2009">2009</option>
                                            <option value="2010">2010</option>
                                            <option value="2011">2011</option>
                                            <option value="2012">2012</option>
                                            <option value="2013">2013</option>
                                            <option value="2014">2014</option>
                                            <option value="2015">2015</option>
                                            <option value="2016">2016</option>
                                            <option value="2017">2017</option>
                                            <option value="2018">2018</option>
                                        </select>
                                        </div>
                                    </div>
                                    <div class="col-sm-3" style="margin-top:20px">
                                       <span name="marcador_nome[]" > Ambiental </span>
                                       <input type="hidden" name="marcador_valor[]" value="1"  >

                                       <input type="checkbox" class="js-switch" onchange="desmarca('x')" name="marcador_checker[]" value="1" data-color="#26c6da" data-size="small" data-secondary-color="#f62d51">

                                    </div>
                                    <div class="col-sm-1 nopadding" style="right:40px;margin-top:10px">
                                        <div class="form-group">
                                            <div class="input-group">
                                                <div class="input-group-append">
                                                    <button class="btn btn-success" type="button" onclick="education_fields();"><i class="fa fa-plus"></i></button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    
                                </div>
                                </div>
                            </div>
                        </div>  
                        <!-- div dos protocolos -->
                        <div class="form-group">
                        <button type="submit" class="btn btn-success waves-effect waves-light">Adicionar</button>
                        <button type="button" onclick="voltar();" class="btn btn-inverse waves-effect waves-light">Voltar</button>
                        <a href="/index" style="display:none" id="ex">Triggerable link</a>
                       
                        </div>
                    </form>
                </div>
            </div>

            



        </div>
    </div>
</div>


<script>
	function voltar(){
		$('#ex').click();
		location.href=$('#ex').attr('href');
	}
</script>




<script>
    function desmarca(posicao){
        var marcador_checker = document.getElementsByName('marcador_checker[]');
        var ano = document.getElementsByName('ano[]');
        var marcador_nome = document.getElementsByName('marcador_nome[]');
        var marcador_valor = document.getElementsByName('marcador_valor[]');
        if(posicao == 'x') posicao = marcador_checker.length-1;
        if (marcador_checker[posicao].checked){
            //colocar disable do ano disabled
            ano[posicao].disabled = "TRUE";
            marcador_nome[posicao].innerHTML="Comercial";
            marcador_valor[posicao].value = "2";
        }else{
           ano[posicao].removeAttribute('disabled');
           marcador_nome[posicao].innerHTML="Ambiental"; 
           marcador_valor[posicao].value = "1";
        }
        
    }
</script>




<!-- chamada do Javascript da div dinamida dos protocolos -->
<script src="../assets/plugins/dff/dff.js" type="text/javascript"></script>



<!-- Fechando as divs e o body do header -- >
</div>    
</div>
</div>


<!-- ============================================================== -->
    <!-- End Wrapper -->
    <!-- ============================================================== -->
    <!-- ============================================================== -->
    <!-- All Jquery -->
    <!-- ============================================================== -->
    <script src="../assets/plugins/jquery/jquery.min.js"></script>
    <!-- Bootstrap tether Core JavaScript -->
    
    
    
    <!-- ============================================================== -->
    <!-- This page plugins -->
    <!-- ============================================================== -->
    <script src="../assets/plugins/switchery/dist/switchery.min.js"></script>
    
    <script>
    jQuery(document).ready(function() {
        // Switchery
        var marcador_checker = document.getElementsByName('marcador_checker[]');
        $('.js-switch').each(function() {
            new Switchery($(this)[0], $(this).data());
        });
        marcador_checker[0].value = "chamado";
    });
    </script>
    
   
</body>

<!-- Chamando o footer.blade.php que contem as chamadas do js e o footer -->
<?php echo $__env->make('footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<script src="../assets/plugins/bootstrap-select/bootstrap-select.min.js" type="text/javascript"></script>
<script src="js/mask.js"></script>
<script src="../assets/plugins/typeahead.js-master/dist/typeahead.bundle.min.js"></script>
<script src="../assets/plugins/typeahead.js-master/dist/typeahead-init.js"></script>