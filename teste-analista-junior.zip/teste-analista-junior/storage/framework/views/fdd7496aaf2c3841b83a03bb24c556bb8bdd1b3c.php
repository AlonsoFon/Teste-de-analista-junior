<!DOCTYPE html>
<html lang="en">

<!-- Chamando o header.blade.php que contem as chamadas do css e o header -->

<?php echo $__env->make('header_index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>


<div class="row">
    <div class="col-10">
        <div class="card card-body" style=" left:115px; margin-top: 20px;">
            <h3 class="box-title m-b-0">Cadastro de planos</h3>
            <p class="text-muted m-b-30 font-13"> Insira as informações abaixo </p>
            
            <div class="row">
                <div class="col-sm-12 col-xs-12">
                	
                    <form class="floating-labels m-t-40" class="floating-labels m-t-40">
                        <div class="form-group">
                            <label for="exampleInputEmail1">Nome do produto</label>
                            <input type="text" class="form-control" id="nome" name="nome" value="" > 
                            <?php if(count($errors) > 0): ?>
                            	<?php if($errors->has('nome')): ?> 
                                    <br>
        							<div class = "alert alert-danger">
            							<ul>
    									<li><?php echo e($errors->first('nome')); ?></li>
										</ul>
        							</div>
       						 	<?php endif; ?>
       						 <?php endif; ?>
                            <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                        </div>
                        <div class="form-group">
                            <label for="exampleInputEmail1">Descrição do produto</label>
                            <input type="text" class="form-control" id="descricao" name="descricao" >
                            <?php if(count($errors) > 0): ?>
                            	<?php if($errors->has('descricao')): ?> 
                                    <br>
        							<div class = "alert alert-danger">
            							<ul>
    									<li><?php echo e($errors->first('descricao')); ?></li>
										</ul>
        							</div>
       						 	<?php endif; ?>
       						 <?php endif; ?>
                        </div>
                        
                        <div class="form-group">
                            <label for="exampleInputEmail1">Valor do produto</label>
                            <input type="text" class="form-control" id="valor" name="valor" >
                             <?php if(count($errors) > 0): ?>
                            	<?php if($errors->has('valor')): ?> 
                                    <br>
        							<div class = "alert alert-danger">
            							<ul>
    									<li><?php echo e($errors->first('valor')); ?></li>
										</ul>
        							</div>
       						 	<?php endif; ?>
       						 <?php endif; ?>
                        </div>
                        <div class="form-group">
                            <label for="exampleInputEmail1">Quantidade de protocolos</label>
                            <input type="text" class="form-control" id="quantidade" name="quantidade" >
                             <?php if(count($errors) > 0): ?>
                                <?php if($errors->has('quantidade')): ?> 
                                    <br>
                                    <div class = "alert alert-danger">
                                        <ul>
                                        <li><?php echo e($errors->first('quantidade')); ?></li>
                                        </ul>
                                    </div>
                                <?php endif; ?>
                             <?php endif; ?>
                        </div>
                        <div class="form-group" style="margin-top:30px">
                            Duração do plano
                        </div>
                        <div class="form-group">
                            <select  class="custom-select" name="duracao">
                                <option value="3">3 meses</option>
                                <option value="6">6 meses</option>
                                <option value="12">1 ano</option>
                            </select>
                             <?php if(count($errors) > 0): ?>
                            	<?php if($errors->has('duracao')): ?> 
                                    <br>
        							<div class = "alert alert-danger">
            							<ul>
    									<li><?php echo e($errors->first('duracao')); ?></li>
										</ul>
        							</div>
       						 	<?php endif; ?>
       						 <?php endif; ?>
                        </div>
                        

                       
                        <div class="form-group">
                        <button type="submit" formmethod="post" class="btn btn-success waves-effect waves-light m-r-10">Cadastrar</button>
                        <button type="button" onclick="voltar();" class="btn btn-inverse waves-effect waves-light">Voltar</button>
                        <a href="/index" style="display:none" id="ex">Triggerable link</a>
                    	</div>
                    </form>
                </div>
            </div>

            



        </div>
    </div>
</div>


<script>
	function voltar(){
		$('#ex').click();
		location.href=$('#ex').attr('href');
	}
</script>





<!-- chamada do Javascript da div dinamida dos protocolos -->
<script src="../assets/plugins/dff/dff.js" type="text/javascript"></script>



<!-- Fechando as divs e o body do header -- >
</div>    
</div>
</div>


<!-- ============================================================== -->
    <!-- End Wrapper -->
    <!-- ============================================================== -->
    <!-- ============================================================== -->
    <!-- All Jquery -->
    <!-- ============================================================== -->
    <script src="../assets/plugins/jquery/jquery.min.js"></script>
    <!-- Bootstrap tether Core JavaScript -->
    
    
    
    <!-- ============================================================== -->
    <!-- This page plugins -->
    <!-- ============================================================== -->
    <script src="../assets/plugins/switchery/dist/switchery.min.js"></script>
    
   
   
</body>

<!-- Chamando o footer.blade.php que contem as chamadas do js e o footer -->
<?php echo $__env->make('footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<script src="../assets/plugins/bootstrap-select/bootstrap-select.min.js" type="text/javascript"></script>
<script src="js/mask.js"></script>
<script src="../assets/plugins/typeahead.js-master/dist/typeahead.bundle.min.js"></script>
<script src="../assets/plugins/typeahead.js-master/dist/typeahead-init.js"></script>