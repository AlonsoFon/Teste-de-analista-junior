<!DOCTYPE html>
<html lang="en">

<!-- Chamando o header.blade.php que contem as chamadas do css e o header -->

<?php echo $__env->make('header_index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>


<div class="row">
    <div class="col-10">
        <div class="card card-body" style=" left:115px; margin-top: 20px;">
            <h3 class="box-title m-b-0">Editar plano</h3>
            <p class="text-muted m-b-30 font-13"> Edite as informações abaixo </p>
            
            <div class="row">
                <div class="col-sm-12 col-xs-12">
                	
                    <form class="floating-labels m-t-40" class="floating-labels m-t-40" id="editar_produto" action="/salvar_edicao" method="post">
                        <div class="form-group">
                            <label for="exampleInputEmail1">Nome do produto</label>
                            <input type="text" class="form-control" id="nome" name="nome" value="<?php echo e($nome_produto); ?>" > 
                            <?php if(count($errors) > 0): ?>
                            	<?php if($errors->has('nome')): ?> 
                                    <br>
        							<div class = "alert alert-danger">
            							<ul>
    									<li><?php echo e($errors->first('nome')); ?></li>
										</ul>
        							</div>
       						 	<?php endif; ?>
       						 <?php endif; ?>
                            <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                        </div>
                        <div class="form-group">
                            <label for="exampleInputEmail1">Descrição do produto</label>
                            <input type="text" class="form-control" id="descricao" name="descricao" value="<?php echo e($descricao_produto); ?>" >
                            <?php if(count($errors) > 0): ?>
                            	<?php if($errors->has('descricao')): ?> 
                                    <br>
        							<div class = "alert alert-danger">
            							<ul>
    									<li><?php echo e($errors->first('descricao')); ?></li>
										</ul>
        							</div>
       						 	<?php endif; ?>
       						 <?php endif; ?>
                        </div>
                        
                        <div class="form-group">
                            <label for="exampleInputEmail1">Valor do produto</label>
                            <input type="text" class="form-control" id="valor" name="valor" value="<?php echo e($valor_produto); ?>" >
                             <?php if(count($errors) > 0): ?>
                            	<?php if($errors->has('valor')): ?> 
                                    <br>
        							<div class = "alert alert-danger">
            							<ul>
    									<li><?php echo e($errors->first('valor')); ?></li>
										</ul>
        							</div>
       						 	<?php endif; ?>
       						 <?php endif; ?>
                        </div>
                        <div class="form-group">
                            <label for="exampleInputEmail1">Quantidade de protocolos</label>
                            <input type="text" class="form-control" id="quantidade" name="quantidade" value="<?php echo e($quantidade_produto); ?>" >
                             <?php if(count($errors) > 0): ?>
                                <?php if($errors->has('quantidade')): ?> 
                                    <br>
                                    <div class = "alert alert-danger">
                                        <ul>
                                        <li><?php echo e($errors->first('quantidade')); ?></li>
                                        </ul>
                                    </div>
                                <?php endif; ?>
                             <?php endif; ?>
                        </div>
                        <div class="form-group" style="margin-top:30px">
                            Duração do plano
                        </div>
                        <div class="form-group">
                            <select  class="custom-select" name="duracao">
                                <option 
                                <?php if($duracao_produto == "3"){ ?>
                                selected="selected"
                                <?php }?>
                                 value="3">3 meses</option>
                                <option
                                <?php if($duracao_produto == "6"){ ?>
                                selected="selected"
                                <?php }?>
                                 value="6">6 meses</option>
                                <option
                                <?php if($duracao_produto == "12"){ ?>
                                selected="selected"
                                <?php }?>
                                 value="12">1 ano</option>
                            </select>
                             <?php if(count($errors) > 0): ?>
                            	<?php if($errors->has('duracao')): ?> 
                                    <br>
        							<div class = "alert alert-danger">
            							<ul>
    									<li><?php echo e($errors->first('duracao')); ?></li>
										</ul>
        							</div>
       						 	<?php endif; ?>
       						 <?php endif; ?>
                        </div>
                        

                       
                        <div class="form-group">
                        <button type="button" onclick="editar();" class="btn btn-success waves-effect waves-light">Editar</button>
                        <button type="button" onclick="voltar();" class="btn btn-inverse waves-effect waves-light">Voltar</button>
                        <a href="/visualiza_produtos" style="display:none" id="ex">Triggerable link</a>
                    	</div>

                        <input type="hidden" name="nome_produto2" value="<?php echo e($nome_produto); ?>">
                        <input type="hidden" name="id_produto2" value="<?php echo e($id_produto); ?>">
                        <input type="hidden"  name="valor_produto2" value="<?php echo e($valor_produto); ?>">
                        <input type="hidden"  name="quantidade_produto2" value="<?php echo e($quantidade_produto); ?>">
                        <input type="hidden"  name="descricao_produto2" value="<?php echo e($descricao_produto); ?>">
                        <input type="hidden"  name="duracao_produto2" value="<?php echo e($duracao_produto); ?>">

                    </form>
                </div>
            </div>

            



        </div>
    </div>
</div>


<script>
	function voltar(){
		$('#ex').click();
		location.href=$('#ex').attr('href');
	}
</script>

<script>
    function editar(){
        document.getElementById("editar_produto").submit();
    }
</script>





<!-- chamada do Javascript da div dinamida dos protocolos -->
<script src="../assets/plugins/dff/dff.js" type="text/javascript"></script>



<!-- Fechando as divs e o body do header -- >
</div>    
</div>
</div>


<!-- ============================================================== -->
    <!-- End Wrapper -->
    <!-- ============================================================== -->
    <!-- ============================================================== -->
    <!-- All Jquery -->
    <!-- ============================================================== -->
    <script src="../assets/plugins/jquery/jquery.min.js"></script>
    <!-- Bootstrap tether Core JavaScript -->
    
    
    
    <!-- ============================================================== -->
    <!-- This page plugins -->
    <!-- ============================================================== -->
    <script src="../assets/plugins/switchery/dist/switchery.min.js"></script>
    
   
   
</body>

<!-- Chamando o footer.blade.php que contem as chamadas do js e o footer -->
<?php echo $__env->make('footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<script src="../assets/plugins/bootstrap-select/bootstrap-select.min.js" type="text/javascript"></script>
<script src="js/mask.js"></script>
<script src="../assets/plugins/typeahead.js-master/dist/typeahead.bundle.min.js"></script>
<script src="../assets/plugins/typeahead.js-master/dist/typeahead-init.js"></script>