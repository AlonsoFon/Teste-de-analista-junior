<!DOCTYPE html>
<html lang="en">


<!-- Chamando o header.blade.php que contem as chamadas do css e o header -->
<?php echo $__env->make('header_index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php if(session('alert')): ?>
    <div class="alert alert-success">
        <?php echo e(session('alert')); ?>

    </div>
<?php endif; ?>

<?php if(session('error1')): ?>
    <div class="alert alert-danger">
        <?php echo e(session('error1')); ?>

    </div>
<?php endif; ?>

<!-- Incluindo o model usuario para poder manipular o banco e preparando os protocolos e o ano -->
<?php 

function sendMessage(){

        $content = array(
            "en" => 'Esta eh uma msg de ate 100 caracteres'
            );
        $Headings = array(
            "en" => 'Esse eh um titulo'
            );
        $fields = array(
            'app_id' => "04d9a36d-4ec7-4b51-9ad2-7e4664417186",
            'include_player_ids' => array("3cb95584-7313-4b27-a834-4b3bea5ba88b"),
            'data' => array("foo" => "bar"),
            'contents' => $content,
            'headings' => $Headings,
            'url' => "localhost:8000/cadastro"
        );
        
        $fields = json_encode($fields);
       
        
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, "https://onesignal.com/api/v1/notifications");
        curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json; charset=utf-8',
                                                   'Authorization: Basic NGEwMGZmMjItY2NkNy0xMWUzLTk5ZDUtMDAwYzI5NDBlNjJj'));
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
        curl_setopt($ch, CURLOPT_HEADER, FALSE);
        curl_setopt($ch, CURLOPT_POST, TRUE);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $fields);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);

        $response = curl_exec($ch);
        curl_close($ch);
        
        return $response;
    }
    
    $response = sendMessage();
    $return["allresponses"] = $response;
    $return = json_encode( $return);
    
   

    use App\Protocolo;
    use App\Usuario;
	$Protocolo = Protocolo::all();
    $protocolo = array();
    $ano = array();
    $tipo = array();
    $arquivado = array();
    $descricao = array();
    if($tipo_usuario == 0){
    	foreach($Protocolo as $row){
    		if ($row->email == $email){
    			$protocolo[] = $row->protocolo;
    			$ano[] = $row->ano;
                $tipo[] = $row->tipo;
                $arquivado[] = $row->arquivado;
                $descricao[] = $row->descricao;
    		}
    	} 
    }
    $tamanho = count($protocolo);
?>

<!-- Pagina do Usuario -->
<?php
    //tipo de usuario = 0 para usuarios comuns
    if($tipo_usuario == 0){  
?>
<div class="row">
                    <!-- Column -->
                    <div class="col-lg-10 col-md-12">
                        <div class="card" style="left:150px; margin-top:20px;">
                            <div class="card-body" >
                                <div class="d-flex no-block">
                                    <h4 class="card-title">Protocolos cadastrados</h4>
                                    <!-- div do select para selecionar a ordenação (qlq coisa)
                                    <div class="ml-auto">
                                        <select class="custom-select">
                                            <option selected="">Electronics</option>
                                            <option value="1">Kitchen</option>
                                            <option value="2">Crocory</option>
                                            <option value="3">Wooden</option>
                                        </select>
                                    </div>
                                	-->
                                    <div style="margin-left:110px;">
                                    <input type="text" class="form-control"  id="myInput" onkeyup="myFunction()" placeholder="Pesquisar">
                                    </div>
                                    <div style="margin-left:auto; margin-right:0;">

                                        <button type="button" onclick="novo();" class="btn btn-info btn-rounded">Adicionar protocolo </button>
                                        <a href="/adiciona_protocolo" style="display:none" id="novo">Triggerable link</a>
                                    </div>
                                </div>
                                <div class="table-responsive">
                                    <table class="table stylish-table" id="myTable">
                                        <thead>
                                            <tr>
                                                <th>Numero</th>
                                                <th>Ano</th>
                                                <th>Tipo</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                        	<?php
                                        	for ($i = 0; $i < $tamanho ; $i++){
                                            if($arquivado[$i] == "0"){
                                            $ano_aux_numero = $ano[$i];
                                            if($tipo[$i] == "1"){ 
                                                $ano_aux = $ano[$i];
                                                $mensagem1 ="Ambiental";
                                            }
                                            else{
                                                $ano_aux = "----";
                                                $mensagem1 = "Comercial";
                                            }
                                        	echo "<tr>";
                                        		echo "<td>";
                                        			echo "<h6><a href=\"javascript:showprotocolos(".$protocolo[$i].",".$ano_aux_numero.",".$tipo[$i].",'".$mensagem1."');\" class=\"link\"> ".$protocolo[$i]."</a></h6><small class=\"text-muted\">".$descricao[$i]." </small>";
                                        		echo "</td>";
                                        		echo "<td>";
                                        			echo "<h5>".$ano_aux."</h5>";
                                        		echo "</td>";
                                                echo "<td>";
                                                    echo "<h5>".$mensagem1."</h5>";
                                                echo "</td>";
                                                echo "<td>";
                                                echo "<button type=\"button\" onclick=\"showprotocolos(".$protocolo[$i].",".$ano_aux_numero.",".$tipo[$i].");\" class=\"btn btn-success waves-effect waves-light m-r-10\">Andamento</button> ";
                                                echo "</td>";
                                               echo "<td>";
                                               echo "<button type=\"button\" onclick=\"editar_protocolo('".$protocolo[$i]."',".$ano_aux_numero.",'".$email."',".$tipo[$i].");\" class=\"btn btn-success waves-effect waves-light m-r-10\">Editar</button> ";
                                                echo "</td>";
                                                echo "<td>";
                                                echo "<button type=\"button\" onclick=\"arquivaprotocolos('".$protocolo[$i]."',".$ano_aux_numero.",'".$email."',".$tipo[$i].");\" class=\"btn btn-inverse waves-effect waves-light m-r-10\">Arquivar</button> ";
                                                echo "</td>";
                                        	echo "</tr>";
                        
                                        	}
                                            }
                                        	?>
                                            <form id="protocolos" action="/protocolos" method="post">
                                <input type="hidden" name="protocolo" value="">
                                <input type="hidden" name="tipo2" value="">
                                <input type="hidden" name="editar_protocolo" value="0">
                                <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                                <input type="hidden"  name="ano" value="">
                                <input type="hidden"  name="email_arquivado" value="0">
                                <input type="hidden" id="channel" name="channel" value="<?php echo e($email); ?>">
                                <input type="hidden"  name="tipo_arquivado" value="0">
                            </form>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                </div>


<!-- Fechando as divs e o body do header -->

<!-- Pagina do admin -->
<?php
    }else{
        $Usuario = Usuario::all();
        $usuario_email = array();
        $usuario_nome = array();
        $contador = 0;
        $ativos = 0;
        $inativos = 0; 
        $ativos_mes = 0;
        $inativos_mes = 0; 
        foreach($Usuario as $row){
            if ($row->email != $email){
                $usuario_email[$contador] = $row->email;
                $usuario_nome[$contador] = $row->nome;
                $usuario_ativo[$contador] = $row->ativo;
                $contador ++;
                $var = new DateTime(' -1 month');
                if ($row->ativo == "1"){
                    if($row->updated_at >= $var ) $ativos_mes ++;
                    $ativos ++;
                }else{
                     if($row->updated_at >= $var ) $inativos_mes ++;
                    $inativos ++;
                }
            }
        }
        $tamanho = count($usuario_email);
?>
<div class="row">
    <div class="col-lg-4 col-md-4">
                        <div class="card" style=" margin-top:20px;">
                            <img class="" src="../assets/images/background/weatherbg.jpg" alt="Card image cap">
                            <div class="card-img-overlay" style="height:110px;">
                                <h3 class="card-title text-white m-b-0 dl">Clientes ativos</h3>
                               
                            </div>
                            <div class="card-body weather-small">
                                <div class="row">
                                    <div class="col-8 b-r align-self-center">
                                        <div class="d-flex">
                                            <div class="display-6 text-info"><i class="wi wi-day-rain-wind"></i></div>
                                            <div class="m-l-20">
                                                <h1 class="font-light text-info m-b-0"><?php echo e($ativos_mes); ?></h1>
                                                <small>Mes</small>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-4 text-center">
                                        <h1 class="font-light m-b-0"><?php echo e($ativos); ?></h1>
                                        <small>Total</small>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Column -->
                    <div class="col-lg-7 col-md-12">
                        <div class="card" style=" margin-top:20px;">
                            <div class="card-body" >
                                <div class="d-flex no-block">
                                    <h4 class="card-title">Usuarios cadastrados</h4>
                                    <!-- div do select para selecionar a ordenação (qlq coisa)
                                    <div class="ml-auto">
                                        <select class="custom-select">
                                            <option selected="">Electronics</option>
                                            <option value="1">Kitchen</option>
                                            <option value="2">Crocory</option>
                                            <option value="3">Wooden</option>
                                        </select>
                                    </div>
                                    -->
                                </div>
                                <div class="table-responsive">
                                    <table class="table stylish-table">
                                        <thead>
                                            <tr>
                                                <th>Email do usuario</th>
                                                <th>Nome do usuario</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php
                                            $tamanho_aux = 0;
                                            for ($i = 0; $i < $tamanho ; $i++){
                                            
                                            
                                            echo "<tr>";
                                                echo "<td>";
                                                    echo "<h6><a href=\"javascript:showprotocolos(".$usuario_email[$i].",".$usuario_nome[$i].");\" class=\"link\"> ".$usuario_email[$i]."</a></h6><small class=\"text-muted\">Descrição </small>";
                                                echo "</td>";
                                                echo "<td>";
                                                    echo "<h5>".$usuario_nome[$i]."</h5>";
                                                echo "</td>";
                                                if ($usuario_ativo[$i] == 1){
                                                echo "<td>";
                                                echo "<button type=\"button\" onclick=\"desativarUsuario('".$usuario_email[$i]."',1);\" class=\"btn btn-inverse waves-effect waves-light m-r-10\">Desativar Cadastro</button> ";
                                                echo "</td>";
                                                }else{
                                                echo "<td>";
                                                echo "<button type=\"button\" onclick=\"desativarUsuario('".$usuario_email[$i]."',2);\" class=\"btn btn-success waves-effect waves-light m-r-10\">Ativar Cadastro</button> ";
                                                echo "</td>";
                                                }
                                            echo "</tr>";
                        
                                            }
                                            ?>
                                            <form id="desativar" action="/desativar" method="post">
                                <input type="hidden" name="email_desativado" value="">
                                <input type="hidden" id="channel" name="channel" value="<?php echo e($email); ?>">
                                <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                                <input type="hidden"  name="acao" value="">
                            </form>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                </div>
            <div class="row">
    <div class="col-lg-4 col-md-4">
                        <div class="card">
                            <img class="" src="../assets/images/background/weatherbg.jpg" alt="Card image cap">
                            <div class="card-img-overlay" style="height:110px;">
                                <h3 class="card-title text-white m-b-0 dl">Clientes Inativos</h3>
                               
                            </div>
                            <div class="card-body weather-small">
                                <div class="row">
                                    <div class="col-8 b-r align-self-center">
                                        <div class="d-flex">
                                            <div class="display-6 text-info"><i class="wi wi-day-rain-wind"></i></div>
                                            <div class="m-l-20">
                                                <h1 class="font-light text-info m-b-0"><?php echo e($inativos_mes); ?></h1>
                                                <small>Mes</small>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-4 text-center">
                                        <h1 class="font-light m-b-0"><?php echo e($inativos); ?></h1>
                                        <small>Total</small>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-8 col-xlg-9 col-md-7">
                        <div class="card">
                            <div class="card-body">
                                <div class="d-flex flex-wrap">
                                    <div>
                                        <h3 class="card-title">Newsletter Campaign</h3>
                                        <h6 class="card-subtitle">Overview of Newsletter Campaign</h6>
                                    </div>
                                    <div class="ml-auto align-self-center">
                                        <ul class="list-inline m-b-0">
                                            <li>
                                                <h6 class="text-muted text-success"><i class="fa fa-circle font-10 m-r-10 "></i>Open Rate</h6> </li>
                                            <li>
                                                <h6 class="text-muted text-info"><i class="fa fa-circle font-10 m-r-10"></i>Recurring Payments</h6> </li>
                                        </ul>
                                    </div>
                                </div>
                                <div class="campaign ct-charts"></div>
                                <div class="row text-center">
                                    <div class="col-lg-4 col-md-4 m-t-20">
                                        <h1 class="m-b-0 font-light">5098</h1><small>Total Sent</small></div>
                                    <div class="col-lg-4 col-md-4 m-t-20">
                                        <h1 class="m-b-0 font-light">4156</h1><small>Mail Open Rate</small></div>
                                    <div class="col-lg-4 col-md-4 m-t-20">
                                        <h1 class="m-b-0 font-light">1369</h1><small>Click Rate</small></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>


<?php

    }  
?>
</div>
</div>
</div>


<script>
function myFunction() {
  // Declare variables 
  var input, filter, table, tr, td, i;
  input = document.getElementById("myInput");
  filter = input.value.toUpperCase();
  table = document.getElementById("myTable");
  tr = table.getElementsByTagName("tr");

  // Loop through all table rows, and hide those who don't match the search query
  for (i = 0; i < tr.length; i++) {
    td = tr[i].getElementsByTagName("td")[0];
    if (td) {
      if (td.innerHTML.toUpperCase().indexOf(filter) > -1) {
        tr[i].style.display = "";
      } else {
        tr[i].style.display = "none";
      }
    } 
  }
}
</script>


<script>
	function showprotocolos(protocolo,ano,tipo,descarte){
        document.getElementsByName('protocolo')[0].value = protocolo;
        document.getElementsByName('ano')[0].value = ano;
        document.getElementsByName('tipo2')[0].value = tipo;
        
        document.getElementById("protocolos").submit();
	}
</script>
<script>
    function arquivaprotocolos(protocolo,ano,email_aux,tipo){
        
        document.getElementsByName('protocolo')[0].value = protocolo;
        document.getElementsByName('ano')[0].value = ano;
        document.getElementsByName('email_arquivado')[0].value = email_aux;
        document.getElementsByName('tipo_arquivado')[0].value = tipo;
        document.getElementById("protocolos").submit();
    }
</script>

<script>
    function novo(){
        $('#novo').click();
        location.href=$('#novo').attr('href');
    }
</script>

<script>
    function editar_protocolo(protocolo,ano,email_aux,tipo){
        
        document.getElementsByName('protocolo')[0].value = protocolo;
        document.getElementsByName('ano')[0].value = ano;
        document.getElementsByName('email_arquivado')[0].value = email_aux;
        document.getElementsByName('tipo_arquivado')[0].value = tipo;
        document.getElementsByName('editar_protocolo')[0].value = "1";
        document.getElementById("protocolos").submit();
    }
</script>

<script>
    function desativarUsuario(email_aux,acao){
        document.getElementsByName('email_desativado')[0].value = email_aux;
        document.getElementsByName('acao')[0].value = acao;
        document.getElementById("desativar").submit();
    }
</script>


<script src="https://cdn.onesignal.com/sdks/OneSignalSDK.js" async=""></script>
<script>
  var OneSignal = window.OneSignal || [];
  OneSignal.push(function() {
    OneSignal.init({
      appId: "04d9a36d-4ec7-4b51-9ad2-7e4664417186",
      autoRegister: false,
      notifyButton: {
        enable: true, /* Required to use the Subscription Bell */
        size: 'medium', /* One of 'small', 'medium', or 'large' */
        theme: 'default', /* One of 'default' (red-white) or 'inverse" (white-red) */
        position: 'bottom-right', /* Either 'bottom-left' or 'bottom-right' */
        offset: {
            bottom: '0px',
            left: '0px', /* Only applied if bottom-left */
            right: '0px' /* Only applied if bottom-right */
        },
        prenotify: true, /* Show an icon with 1 unread message for first-time site visitors */
        showCredit: false, /* Hide the OneSignal logo */
        text: {
            'tip.state.unsubscribed': 'Se inscreva para receber notificações',
            'tip.state.subscribed': "Você esta inscrito para receber notificações",
            'tip.state.blocked': "notificações bloqueadas",
            'message.prenotify': 'Clique para receber notificações',
            'message.action.subscribed': "Obrigado por se inscrever!",
            'message.action.resubscribed': "Você esta inscrito para receber notificações",
            'message.action.unsubscribed': "Você não receberá notificações",
            'dialog.main.title': 'Inscreva-se',
            'dialog.main.button.subscribe': 'Aceitar',
            'dialog.main.button.unsubscribe': 'Cancelar',
            'dialog.blocked.title': 'Desbloquear notificações',
            'dialog.blocked.message': "Follow these instructions to allow notifications:"
        }
    },
    });
    OneSignal.getUserId(function(userId) {
        document.getElementsByName('channel')[0].value = userId;
    });
  });
</script> 

  
</body>
<!-- Chamando o footer.blade.php que contem as chamadas do js e o footer -->
<?php echo $__env->make('footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>