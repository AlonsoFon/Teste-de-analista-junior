<?php

namespace App\Http\Controllers;

use App\Http\Requests;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Usuario;
use App\Filmes;
use App\Endereco;


class UsuariosController extends Controller
{

    

    //*** funcao index chamada pela logar, responsavel por verificar se tem session aberta com email existente
    public function index(Request $request){
      $email = $request->session()->get('email');
      $nome = $request->session()->get('nome');
      if($email != ""){
       return view('index')->with('email',$email)->with('nome',$nome);
      }else{
        return redirect('/login');
      }
    }
    

    //*** funcao login chamada quando usuario digita /login na tela ou /index sem ter uma session valida ativa
    public function login(){
      return view('login');
    }

    //*** funcao logout chamada quando o usuario clica no botao logout, responsavel por destruir a session ativa
    public function logout(Request $request){
      $request->session()->flush();
      return redirect('/login');
    }

    

    //*** funcao logar chamada quando o usuario clica no botao logar da tela de login responsavel por verificar email e senha, se corretos, registrar uma session com o nome e email do usuario e redirecionar para index
    public function logar(Request $request){
      $this->validate($request,[
         'email' => 'required',
         'senha' => 'required',
      ]);
      $nome = "";
      
      //fazendo a variavel receber as informações do submit
      $email = $request->get('email');
      $senha = $request->get('senha');
      //criando uma variavel com todas as informações do banco da tabela usuario
      $Usuario = Usuario::all();
      $erro1 = $erro2 = 1;
      // verificando no banco se o email e a senha digitados estao corretos
      foreach($Usuario as $row){
        if($erro1 == 1){
          if ( ($row->email == $email) && ($row->senha == $senha)){
            $nome = $row->nome;
            $erro1 = 0;
            $erro2 = 0;
          }
        }
      }
      // emitindo o erro caso exista
      if($erro1 == 1 || $erro2 == 1){
       return redirect('/login')->with('error', 'email ou senha incorretos!');
      }
      //redirecionando para a page index se o login e a senha estiverem corretos
      if($erro1 == 0 && $erro2 == 0){
       
        //colocando o email e o nome do usuario na session
        $request->session()->put('email',$email);
        $request->session()->put('nome',$nome);
        return redirect('/index');
      }

    }

    //*** funcao cadastrar chamada quando usuario digita /cadastro na tela ou clica no botao cadastrar novo usuario da tela de login
    public function cadastro(){
    	return view('cadastro');
    }

    //*** funcao para chamar a view de editar perfil
    public function editar_perfil(Request $request){
      $email = $request->session()->get('email');
      $nome = $request->session()->get('nome');
      if($email != ""){
       return view('editar_perfil')->with('email',$email)->with('nome',$nome);
      }else{
        return redirect('/login');
      }
    }
    //*** funcao para chamar a view de adicionar_filmes
    public function adicionar_filmes(Request $request){
      $email = $request->session()->get('email');
      $nome = $request->session()->get('nome');
      if($email != ""){
       return view('adicionar_filmes')->with('email',$email)->with('nome',$nome);
      }else{
        return redirect('/login');
      }
    }

    //*** funcao salvar_adicionar_filmes
    public function salvar_adicionar_filmes(Request $request){
      
      $email = $request->session()->get('email');
      // salvando os filmes
      $titulo = $request->get('titulo');
      $ano = $request->get('ano');
      $diretor = $request->get('diretor');
      $nota_do_filme = $request->get('nota_do_filme');
      $sinopse_do_filme = $request->get('sinopse_do_filme');
      $tamanho_filme = count($titulo);
      $salvou = 0;
      for($i = 0; $i < $tamanho_filme; $i++){
        if($titulo[$i] != null){
          $Filmes = new Filmes();
          $Filmes->email = $email;
          $Filmes->titulo = $titulo[$i];
          $Filmes->ano = $ano[$i];
          $Filmes->diretor = $diretor[$i];
          $Filmes->nota_do_filme = $nota_do_filme[$i];
          $Filmes->sinopse_do_filme = $sinopse_do_filme[$i];
          $salvou ++;
          $Filmes->save();
        } 
      }

      if($salvou > 0) return redirect('/index')->with('alert', 'Filme(s) adicionado(s) com sucesso!');
      else return redirect('/index')->with('error1', 'Você tem que adicionar ao menos um filme com todos os campos preenchidos!');
   }



    //*** funcao para chamar a view de adicionar_enderecos
    public function adicionar_enderecos(Request $request){
      $email = $request->session()->get('email');
      $nome = $request->session()->get('nome');
      if($email != ""){
       return view('adicionar_enderecos')->with('email',$email)->with('nome',$nome);
      }else{
        return redirect('/login');
      }
    }


    //*** funcao salvar_adicionar_enderecos
    public function salvar_adicionar_enderecos(Request $request){
      
       
      $email = $request->session()->get('email');
      // adicionando novos enderecos
      $logradouro = $request->get('logradouro');
      $bairro = $request->get('bairro');
      $numero = $request->get('numero');
      $complemento = $request->get('complemento');
      $cidade = $request->get('cidade');
      $estado = $request->get('estado');


      $tamanho_endereco = count($logradouro);
      $salvou = 0;
      for($i = 0; $i < $tamanho_endereco; $i++ ){
        if ( ($logradouro[$i] != null) ){
          $Endereco = new Endereco();
          $Endereco->email = $email;
          $Endereco->logradouro = $logradouro[$i];
          $Endereco->bairro = $bairro[$i];
          $Endereco->numero = $numero[$i];
          $Endereco->complemento = $complemento[$i];
          $Endereco->cidade = $cidade[$i];
          $Endereco->estado = $estado[$i];
          $salvou++;
          $Endereco->save();

        }  
      }
      
      
      

      if($salvou > 0)return redirect('/index')->with('alert', 'Endereço(s) adicionado(s) com sucesso!');
      else return redirect('/index')->with('error1', 'Você tem que adicionar ao menos um endereço com todos os campos preenchidos!');
   }

    

    
    

    //*** funcao para chamar a view de alterar a senha
    public function alterar_senha(Request $request){
      $email = $request->session()->get('email');
      $nome = $request->session()->get('nome');
      if($email != ""){
       return view('alterar_senha')->with('email',$email)->with('nome',$nome);
      }else{
        return redirect('/login');
      }
    }

    //*** funcao para salvar a edicao de senha do usuario
    public function salvar_alterar_senha(Request $request){
      $this->validate($request,[
         'senha' => 'required|confirmed',
         'senha_atual' => 'required',
      ]);
      echo "passou";
      
      $email = $request->session()->get('email');
      $senha_atual = $request->get('senha_atual');
      $senha_nova = $request->get('senha');
      $Usuario = Usuario::all();
      foreach($Usuario as $row){
        if($email == $row->email){
          if($senha_atual == $row->senha){
            $verdade = "1";
          }else{
            $verdade = "0";
          }
        }
      }
      if($verdade == "1"){
        $affectedRows = Usuario::where('email', '=', $email)->update(array('senha' => $senha_nova));
        return redirect('/index')->with('alert', 'Senha com sucesso!');
      }else{
        return redirect('/editar_senha')->with('alert', 'Senha atual incorreta!');
      }
      
    }
    
    //*** funcao salvar_editar_perfil
    public function salvar_editar_perfil(Request $request){
      $this->validate($request,[
         'nome' => 'required',
         'sobrenome' => 'required',
         'telefone' => 'required',
         'cpf' => 'required|cpf',
         'rg' => 'required',
         'titulacao' => 'required',
      ]);
      //Usando o model usuario para gravar as informacoes
      $Usuario_pes = Usuario::all();
      $id = $request->get('id'); 
      $email = $request->session()->get('email');
      foreach ($Usuario_pes as $row) {
        if($row->email == $email) $senha = $row->senha;
      }
      $Usuario = new Usuario();
      $Usuario->nome = $request->get('nome');
      $Usuario->sobrenome = $request->get('sobrenome');
      $Usuario->email = $email;
      $Usuario->senha = $senha;
      $Usuario->telefone = $request->get('telefone');
      $Usuario->cpf = $request->get('cpf');
      $Usuario->rg = $request->get('rg');
      $Usuario->titulacao = $request->get('titulacao');
      $logradouro = $request->get('logradouro');
      $bairro = $request->get('bairro');
      $numero = $request->get('numero');
      $complemento = $request->get('complemento');
      $cidade = $request->get('cidade');
      $estado = $request->get('estado');
      $affectedRows = Usuario::where('id','=',$id)->delete();
      $affectedRows = Endereco::where('email','=',$email)->delete();
      $affectedRows = Filmes::where('email','=',$email)->delete();



      $primeiro_endereco = $request->get('primeiro_endereco');
      $tamanho_endereco = count($logradouro);
      $tem_primeiro_endereco = 0;
      for($i = 0; $i < $tamanho_endereco; $i++ ){
        if($primeiro_endereco == "-1"){
          if ( $tem_primeiro_endereco == 0 ){
            if ( ($logradouro[$i] != null) ){
              $Usuario->logradouro = $logradouro[$i];
              $Usuario->bairro = $bairro[$i];
              $Usuario->numero = $numero[$i];
              $Usuario->complemento = $complemento[$i];
              $Usuario->cidade = $cidade[$i];
              $Usuario->estado = $estado[$i];
              $tem_primeiro_endereco = 1;

            }
          }else{
            if ( ($logradouro[$i] != null) ){
              $Endereco = new Endereco();
              $Endereco->email = $email;
              $Endereco->logradouro = $logradouro[$i];
              $Endereco->bairro = $bairro[$i];
              $Endereco->numero = $numero[$i];
              $Endereco->complemento = $complemento[$i];
              $Endereco->cidade = $cidade[$i];
              $Endereco->estado = $estado[$i];
              $Endereco->save();
            }
          }
        }else{
          //aqui se ele marcou um endereco como primeiro
          if($i == $primeiro_endereco){
            if ( ($logradouro[$i] != null) ){
              $Usuario->logradouro = $logradouro[$i];
              $Usuario->bairro = $bairro[$i];
              $Usuario->numero = $numero[$i];
              $Usuario->complemento = $complemento[$i];
              $Usuario->cidade = $cidade[$i];
              $Usuario->estado = $estado[$i];

            }
          }else{
            if ( ($logradouro[$i] != null) ){
              $Endereco = new Endereco();
              $Endereco->email = $email;
              $Endereco->logradouro = $logradouro[$i];
              $Endereco->bairro = $bairro[$i];
              $Endereco->numero = $numero[$i];
              $Endereco->complemento = $complemento[$i];
              $Endereco->cidade = $cidade[$i];
              $Endereco->estado = $estado[$i];
              $Endereco->save(); 
            }
          }
        }
      }
      $Usuario->save();
      // salvando os filmes
      $titulo = $request->get('titulo');
      $ano = $request->get('ano');
      $diretor = $request->get('diretor');
      $nota_do_filme = $request->get('nota_do_filme');
      $sinopse_do_filme = $request->get('sinopse_do_filme');
      $tamanho_filme = count($titulo);
      for($i = 0; $i < $tamanho_filme; $i++){
        if($titulo[$i] != null){
          $Filmes = new Filmes();
          $Filmes->email = $email;
          $Filmes->titulo = $titulo[$i];
          $Filmes->ano = $ano[$i];
          $Filmes->diretor = $diretor[$i];
          $Filmes->nota_do_filme = $nota_do_filme[$i];
          $Filmes->sinopse_do_filme = $sinopse_do_filme[$i];
          $Filmes->save();
        } 
      }


      
      

      return redirect('/index')->with('alert', 'Perfil editado com sucesso!');

   }
    
    //*** validacao do formulario de cadastro
    public function cadastrar(Request $request){
      $this->validate($request,[
         'nome' => 'required',
         'sobrenome' => 'required',
         'email' => 'required|unique:usuarios,email',
         'senha' => 'required|confirmed',
         'telefone' => 'required',
         'cpf' => 'required|cpf',
         'rg' => 'required',
         'titulacao' => 'required',
      ]);
      //Usando o model usuario para gravar as informacoes
      $Usuario = new Usuario();
      $Usuario->nome = $request->get('nome');
      $Usuario->sobrenome = $request->get('sobrenome');
      $email = $request->get('email');
      $Usuario->email = $request->get('email');
      $Usuario->senha = $request->get('senha');
      $Usuario->telefone = $request->get('telefone');
      $Usuario->cpf = $request->get('cpf');
      $Usuario->rg = $request->get('rg');
      $Usuario->titulacao = $request->get('titulacao');
      $logradouro = $request->get('logradouro');
      $bairro = $request->get('bairro');
      $numero = $request->get('numero');
      $complemento = $request->get('complemento');
      $cidade = $request->get('cidade');
      $estado = $request->get('estado');



      $primeiro_endereco = $request->get('primeiro_endereco');
      $tamanho_endereco = count($logradouro);
      $tem_primeiro_endereco = 0;
      for($i = 0; $i < $tamanho_endereco; $i++ ){
        if($primeiro_endereco == "-1"){
          if ( $tem_primeiro_endereco == 0 ){
            if ( ($logradouro[$i] != null) ){
              $Usuario->logradouro = $logradouro[$i];
              $Usuario->bairro = $bairro[$i];
              $Usuario->numero = $numero[$i];
              $Usuario->complemento = $complemento[$i];
              $Usuario->cidade = $cidade[$i];
              $Usuario->estado = $estado[$i];
              $tem_primeiro_endereco = 1;

            }
          }else{
            if ( ($logradouro[$i] != null) ){
              $Endereco = new Endereco();
              $Endereco->email = $email;
              $Endereco->logradouro = $logradouro[$i];
              $Endereco->bairro = $bairro[$i];
              $Endereco->numero = $numero[$i];
              $Endereco->complemento = $complemento[$i];
              $Endereco->cidade = $cidade[$i];
              $Endereco->estado = $estado[$i];
              $Endereco->save();
            }
          }
        }else{
          //aqui se ele marcou um endereco como primeiro
          if($i == $primeiro_endereco){
            if ( ($logradouro[$i] != null) ){
              $Usuario->logradouro = $logradouro[$i];
              $Usuario->bairro = $bairro[$i];
              $Usuario->numero = $numero[$i];
              $Usuario->complemento = $complemento[$i];
              $Usuario->cidade = $cidade[$i];
              $Usuario->estado = $estado[$i];

            }
          }else{
            if ( ($logradouro[$i] != null) ){
              $Endereco = new Endereco();
              $Endereco->email = $email;
              $Endereco->logradouro = $logradouro[$i];
              $Endereco->bairro = $bairro[$i];
              $Endereco->numero = $numero[$i];
              $Endereco->complemento = $complemento[$i];
              $Endereco->cidade = $cidade[$i];
              $Endereco->estado = $estado[$i];
              $Endereco->save(); 
            }
          }
        }
      }
      $Usuario->save();
      // salvando os filmes
      $titulo = $request->get('titulo');
      $ano = $request->get('ano');
      $diretor = $request->get('diretor');
      $nota_do_filme = $request->get('nota_do_filme');
      $sinopse_do_filme = $request->get('sinopse_do_filme');
      $tamanho_filme = count($titulo);
      for($i = 0; $i < $tamanho_filme; $i++){
        if($titulo[$i] != null){
          $Filmes = new Filmes();
          $Filmes->email = $email;
          $Filmes->titulo = $titulo[$i];
          $Filmes->ano = $ano[$i];
          $Filmes->diretor = $diretor[$i];
          $Filmes->nota_do_filme = $nota_do_filme[$i];
          $Filmes->sinopse_do_filme = $sinopse_do_filme[$i];
          $Filmes->save();
        } 
      }


      
      

      return redirect('/login')->with('alert', 'Cadastrado realizado com sucesso!');

   }

   
   
}
