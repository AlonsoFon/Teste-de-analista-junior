<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use App\Protocolo;
use App\Movimentacao;

class Insere_no_banco extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'sms:birthday';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Command description';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        $Protocolo = Protocolo::all();
        $protocolo_array = array(); 
        $ano_array = array();
        foreach ($Protocolo as $row_aux ) {
            $protocolo_array[] = $row_aux->protocolo;
            $ano_array[] = $row_aux->ano;
        }
        $url_aux ="http://www.protocolo.sad.mt.gov.br/consulta/ep.php?p_anoProcesso=".$ano_array[0]."&p_numeroProcesso=".$protocolo_array[0];
        // pegando o conteudo da pagina $url_aux e colocando em $conteudo
        $Movimentacao_teste = new Movimentacao();
        $Movimentacao_teste->protocolo = $row_aux->protocolo;
        $ch = curl_init();
        $timeout = 10000;
        curl_setopt($ch, CURLOPT_URL, $url_aux);
        // ENABLE HTTP POST
        curl_setopt ($ch, CURLOPT_POST, 1);

        // SET POST PARAMETERS : FORM VALUES FOR EACH FIELD
        curl_setopt ($ch, CURLOPT_POSTFIELDS, 'protocolo=180397389');
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, $timeout);
        $conteudo = curl_exec ($ch);
        curl_close($ch);
        $Movimentacao_teste->teste = $conteudo;
        $Movimentacao_teste->save();
    }
    
}
